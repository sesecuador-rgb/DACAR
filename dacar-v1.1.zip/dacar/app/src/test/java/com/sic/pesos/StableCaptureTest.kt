package com.sic.pesos

import com.sic.pesos.cycle.CycleConfig
import com.sic.pesos.cycle.CycleDetector
import com.sic.pesos.cycle.WeighingSession
import com.sic.pesos.data.WeightMode
import com.sic.pesos.sics.SicsParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.Locale

/**
 * Modo "guardar sola al estabilizarse": división 1 kg, carga mínima 20 kg, banda de cero 5 kg,
 * estable 800 ms. Sondeo cada 100 ms, como en la tablet.
 */
class StableCaptureTest {
    private lateinit var store: FakeStore
    private lateinit var session: WeighingSession
    private var clock = 0L
    private var ids = 0

    @Before
    fun setUp() {
        store = FakeStore()
        val cfg = CycleConfig.suggested(1.0).copy(captureOnStable = true, stableHoldMs = 800)
        session = WeighingSession(store, CycleDetector(cfg) { "c${++ids}" }, scaleId = 2)
        session.start(1, WeightMode.GROSS)
    }

    private fun feed(sts: String, kg: Double, times: Int = 1) = repeat(times) {
        clock += 100
        val line = String.format(Locale.US, "SIX1 %s 0 N N R 0 0 0 1 N %10.0f %10.0f %10.0f kg\r\n", sts, kg, kg, 0.0)
        session.onResponse(clock, SicsParser.parse(line))
    }

    @Test
    fun se_guarda_sola_al_estabilizarse_sin_retirar_la_carga() {
        feed("S", 0.0, 3)
        feed("D", 500.0, 3)
        feed("S", 965.0, 8)                       // 700 ms estable: todavía no
        assertEquals(0, store.rows.size)
        feed("S", 965.0, 1)                       // 800 ms: se guarda sin descargar
        assertEquals(listOf(965.0), store.rows.map { it.kg })
        assertTrue(session.detector.snapshot().awaitingUnload)
    }

    @Test
    fun la_misma_carga_no_se_guarda_dos_veces() {
        feed("S", 0.0, 3)
        feed("S", 965.0, 60)                      // 6 s quieta sobre la balanza
        feed("D", 980.0, 3); feed("S", 990.0, 20) // se mueve o se le agrega algo sin descargar
        assertEquals(1, store.rows.size)
        feed("D", 2.0, 2); feed("S", 0.0, 2)      // se retira
        feed("D", 400.0, 2); feed("S", 562.0, 10) // siguiente canasta
        assertEquals(listOf(965.0, 562.0), store.rows.map { it.kg })
        assertEquals(listOf(1, 2), store.rows.map { it.seq })
    }

    @Test
    fun oscilacion_o_estable_breve_no_se_guarda() {
        feed("S", 0.0, 3)
        repeat(10) { feed("S", 900.0, 3); feed("D", 910.0, 1) }  // nunca 800 ms seguidos
        feed("S", 900.0, 3); feed("S", 905.0, 3)                   // cambia más de 1 d: reinicia
        assertEquals(0, store.rows.size)
        feed("S", 905.0, 6)
        assertEquals(listOf(905.0), store.rows.map { it.kg })
    }

    @Test
    fun corte_de_conexion_no_duplica_ni_inventa() {
        feed("S", 0.0, 3)
        feed("S", 965.0, 5)
        session.onLinkLost(clock)                  // corte antes de completar los 800 ms
        feed("S", 965.0, 5)
        assertEquals(0, store.rows.size)           // el tiempo estable empieza de nuevo
        feed("S", 965.0, 4)
        assertEquals(1, store.rows.size)
        session.onLinkLost(clock)                  // corte con la carga ya guardada
        feed("S", 965.0, 30)
        assertEquals(1, store.rows.size)           // al volver no se guarda otra vez
    }

    @Test
    fun por_debajo_de_la_carga_minima_no_se_guarda() {
        feed("S", 0.0, 3)
        feed("S", 15.0, 30)                        // 15 kg < 20 kg
        assertEquals(0, store.rows.size)
    }
}
