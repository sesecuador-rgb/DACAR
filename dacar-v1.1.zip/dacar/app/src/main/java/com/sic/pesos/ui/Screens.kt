package com.sic.pesos.ui

import android.app.DatePickerDialog
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sic.pesos.cycle.CycleConfig
import com.sic.pesos.data.Basket
import com.sic.pesos.data.TestRecord
import com.sic.pesos.data.Units
import com.sic.pesos.data.WeightMode
import com.sic.pesos.report.Fmt
import com.sic.pesos.report.ReportData
import com.sic.pesos.settings.LinkSource
import com.sic.pesos.settings.Settings
import com.sic.pesos.sics.LinkState
import com.sic.pesos.sics.SicsParser
import java.io.File
import java.time.LocalDate

// ============================ Historial ============================

@Composable
fun HistoryScreen(s: UiState, vm: PesosViewModel) {
    val ctx = LocalContext.current
    val f = s.filter
    val names = s.scales.associate { it.id to it.settings.name }
    fun scaleName(id: Int) = names[id] ?: "Balanza $id"
    val elementOptions = s.allElements.filter { f.scaleId == null || it.scaleId == f.scaleId }
    val selectedElement = s.allElements.firstOrNull { it.id == f.elementId }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Panel(Modifier.fillMaxWidth(), padding = 12.dp) {
            Text("Buscar registros", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Picker(
                    label = "Balanza",
                    current = f.scaleId?.let { scaleName(it) } ?: "Ambas",
                    options = listOf<Int?>(null) + s.scales.map { it.id },
                    text = { id -> id?.let { scaleName(it) } ?: "Ambas balanzas" },
                    onPick = { id ->
                        // Si el elemento elegido es de la otra balanza, se quita ese filtro.
                        val keepElement = selectedElement?.takeIf { id == null || it.scaleId == id }
                        vm.setFilter(f.copy(scaleId = id, elementId = keepElement?.id))
                    },
                    modifier = Modifier.weight(1f),
                )
                OutlinedButton(
                    onClick = { pickDate(ctx, f.fromDay) { vm.setFilter(f.copy(fromDay = it)) } },
                    modifier = Modifier.weight(0.8f),
                ) { DateLabel("Desde", f.fromDay) }
                OutlinedButton(
                    onClick = { pickDate(ctx, f.toDay ?: f.fromDay) { vm.setFilter(f.copy(toDay = it)) } },
                    modifier = Modifier.weight(0.8f),
                ) { DateLabel("Hasta", f.toDay) }
                Picker(
                    label = "Elemento / prueba",
                    current = selectedElement?.let { el ->
                        if (f.scaleId == null) "${el.label} (${scaleName(el.scaleId)})" else el.label
                    } ?: "Todos",
                    options = listOf<TestRecord?>(null) + elementOptions,
                    text = { el ->
                        el?.let { if (f.scaleId == null) "${it.label}  (${scaleName(it.scaleId)})" else it.label }
                            ?: "Todos los elementos"
                    },
                    onPick = { el -> vm.setFilter(f.copy(elementId = el?.id)) },
                    modifier = Modifier.weight(1.4f),
                )
            }
            Row(
                Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(onClick = {
                    val from = f.fromDay
                    val to = f.toDay
                    if (from != null && to != null && to.isBefore(from)) {
                        vm.setFilter(f.copy(fromDay = to, toDay = from))
                    }
                    vm.search()
                }, modifier = Modifier.height(52.dp)) { Text("Buscar", fontSize = 17.sp) }
                TextButton(onClick = { vm.setFilter(com.sic.pesos.data.HistoryFilter()) }) { Text("Quitar filtros") }
                Spacer(Modifier.weight(1f))
                OutlinedButton(
                    onClick = { vm.export(excel = false) }, enabled = s.results.isNotEmpty(),
                    modifier = Modifier.height(52.dp),
                ) { Text("Exportar PDF", fontSize = 16.sp) }
                OutlinedButton(
                    onClick = { vm.export(excel = true) }, enabled = s.results.isNotEmpty(),
                    modifier = Modifier.height(52.dp),
                ) { Text("Exportar Excel", fontSize = 16.sp) }
            }
        }
        Spacer(Modifier.height(10.dp))

        val several = ReportData.includesSeveralScales(s.results)
        val summary = remember(s.results) {
            ReportData.summarize(s.results) { id -> s.scales.firstOrNull { it.id == id }?.settings?.decimals ?: 2 }
        }
        if (s.searched) {
            val net = summary.netByUnit.entries.joinToString("   ") { (u, v) -> "Neto ${v.toPlainString()} $u" }
            val units = summary.totalUnits?.let { "   Unidades ${Fmt.units(it)}" } ?: ""
            Text(
                "${s.results.size} registros   $net$units",
                fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Pal.Ink,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
            )
        } else {
            Text(
                "Elija los filtros y pulse Buscar. Se pueden combinar balanza, fechas y elemento.",
                fontSize = 16.sp, color = Pal.Muted, modifier = Modifier.padding(4.dp),
            )
        }

        Panel(Modifier.fillMaxWidth().weight(1f), padding = 0.dp) {
            val cols = listOf(
                Col("Fecha", 1.1f), Col("Hora", 0.9f), Col("Balanza", 1f), Col("Elemento", 1.3f),
                Col("Lote", 0.9f), Col("Bruto", 0.9f, true), Col("Tara", 0.7f, true),
                Col("Neto", 0.9f, true), Col("Muestra", 0.8f, true), Col("Unid.", 0.8f, true),
            )
            DataHeader(cols)
            if (s.searched && s.results.isEmpty()) {
                Text("No hay registros con esos filtros.", fontSize = 16.sp, color = Pal.Muted, modifier = Modifier.padding(12.dp))
            }
            LazyColumn(Modifier.weight(1f)) {
                items(s.results, key = { it.w.id }) { r ->
                    val d = s.scales.firstOrNull { it.id == r.w.scaleId }?.settings?.decimals ?: 2
                    DataRow(
                        listOf(
                            Col(Fmt.date(r.w.atMs), 1.1f), Col(Fmt.time(r.w.atMs), 0.9f),
                            Col(scaleName(r.w.scaleId), 1f), Col(r.elementName, 1.3f), Col(r.lote, 0.9f),
                            Col(Fmt.kg(r.w.kg, d), 0.9f, true), Col(Fmt.kg(r.w.tareKg, d), 0.7f, true),
                            Col(Fmt.kg(r.w.netKg, d), 0.9f, true),
                            Col(r.w.sampleKg?.let { Fmt.kg(it, 3) } ?: "—", 0.8f, true),
                            Col(r.units?.let { Fmt.units(it) } ?: "—", 0.8f, true),
                        ),
                        onClick = { vm.editRecord(r) },
                    )
                }
            }
        }
        if (several) {
            Text(
                "Los registros de ambas balanzas se distinguen por la columna Balanza, también en PDF y Excel.",
                fontSize = 13.sp, color = Pal.Muted, modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
private fun DateLabel(label: String, day: LocalDate?) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, fontSize = 12.sp, color = Pal.Muted)
        Text(day?.let { Fmt.day(it) } ?: "Sin límite", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
    }
}

private fun pickDate(ctx: Context, initial: LocalDate?, onPick: (LocalDate) -> Unit) {
    val d = initial ?: LocalDate.now()
    DatePickerDialog(ctx, { _, y, m, day -> onPick(LocalDate.of(y, m + 1, day)) }, d.year, d.monthValue - 1, d.dayOfMonth)
        .show()
}

// ============================ Ajustes ============================

@Composable
fun SettingsScreen(s: UiState, vm: PesosViewModel) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth > maxHeight
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (wide) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    s.scales.forEach { su -> ScaleSettingsCard(su.settings, vm, Modifier.weight(1f)) }
                }
            } else {
                s.scales.forEach { su -> ScaleSettingsCard(su.settings, vm, Modifier.fillMaxWidth()) }
            }
            BasketsCard(s.baskets, vm)
            Text(
                "La app es de solo lectura: solo consulta el peso (SIX1), el firmware (I3) y el número de serie (I4). " +
                    "No envía cero, tara ni cambios de parámetros, y no interfiere con el PLC.",
                fontSize = 14.sp, color = Pal.Muted,
            )
        }
    }
}

@Composable
private fun ScaleSettingsCard(st: Settings, vm: PesosViewModel, modifier: Modifier) {
    var enabled by remember(st) { mutableStateOf(st.enabled) }
    var name by remember(st) { mutableStateOf(st.name) }
    var model by remember(st) { mutableStateOf(st.model) }
    var source by remember(st) { mutableStateOf(st.source) }
    var host by remember(st) { mutableStateOf(st.host) }
    var port by remember(st) { mutableStateOf(st.port.toString()) }
    var poll by remember(st) { mutableStateOf(st.pollMs.toString()) }
    var division by remember(st) { mutableStateOf(st.divisionKg.toString()) }
    var minLoad by remember(st) { mutableStateOf(st.minLoadKg.toString()) }
    var zeroBand by remember(st) { mutableStateOf(st.zeroBandKg.toString()) }
    var samples by remember(st) { mutableStateOf(st.stableSamples.toString()) }
    var unloadMs by remember(st) { mutableStateOf(st.unloadConfirmMs.toString()) }
    var mode by remember(st) { mutableStateOf(st.weightMode) }
    var auto by remember(st) { mutableStateOf(st.autoConnect) }
    var onStable by remember(st) { mutableStateOf(st.captureOnStable) }
    var holdMs by remember(st) { mutableStateOf(st.stableHoldMs.toString()) }
    var error by remember(st) { mutableStateOf<String?>(null) }

    fun d(x: String) = x.trim().replace(',', '.').toDoubleOrNull()

    Panel(modifier.widthIn(max = 760.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Balanza ${st.scaleId}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pal.Ink, modifier = Modifier.weight(1f))
            Text("Activada", color = Pal.Ink)
            Spacer(Modifier.width(6.dp))
            Switch(checked = enabled, onCheckedChange = { enabled = it })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Nombre", name, Modifier.weight(1f)) { name = it }
            Field("Modelo", model, Modifier.weight(1f)) { model = it }
        }
        Spacer(Modifier.height(6.dp))
        Picker(
            label = "Lectura",
            current = source.label,
            options = LinkSource.entries,
            text = { it.label },
            onPick = { source = it },
            modifier = Modifier.fillMaxWidth(),
        )
        if (source == LinkSource.SIMULATOR) {
            Text(
                "SIMULADOR: genera pesos de prueba. No es el equipo real; las pesadas quedan marcadas como SIMULADO.",
                color = Pal.Amber, fontWeight = FontWeight.Bold, fontSize = 14.sp,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("IP del controlador", host, Modifier.weight(2f), KeyboardType.Uri) { host = it }
            Field("Puerto", port, Modifier.weight(1f), KeyboardType.Number) { port = it }
            Field("Consulta (ms)", poll, Modifier.weight(1.2f), KeyboardType.Number) { poll = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Field("División d (kg)", division, Modifier.weight(1f), KeyboardType.Decimal) { division = it }
            OutlinedButton(onClick = {
                d(division)?.takeIf { it > 0 }?.let { dv ->
                    val sug = CycleConfig.suggested(dv)
                    minLoad = sug.minLoadKg.toString()
                    zeroBand = sug.zeroBandKg.toString()
                    samples = sug.stableSamples.toString()
                    unloadMs = sug.unloadConfirmMs.toString()
                }
            }) { Text("Valores sugeridos") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Carga mínima (kg)", minLoad, Modifier.weight(1f), KeyboardType.Decimal) { minLoad = it }
            Field("Banda de cero (kg)", zeroBand, Modifier.weight(1f), KeyboardType.Decimal) { zeroBand = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Picker(
                label = "Guardar la pesada",
                current = if (onStable) "Sola, al estabilizarse" else "Al retirar la carga",
                options = listOf(true, false),
                text = { if (it) "Sola, en cuanto el peso se estabiliza" else "Al retirar la carga (máximo estable)" },
                onPick = { onStable = it },
                modifier = Modifier.weight(1.4f),
            )
            Field("Estable durante (ms)", holdMs, Modifier.weight(1f), KeyboardType.Number) { holdMs = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Lecturas estables", samples, Modifier.weight(1f), KeyboardType.Number) { samples = it }
            Field("Tiempo en cero (ms)", unloadMs, Modifier.weight(1f), KeyboardType.Number) { unloadMs = it }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Picker(
                label = "Valor a registrar (elementos nuevos)",
                current = mode.label,
                options = WeightMode.entries,
                text = { it.label },
                onPick = { mode = it },
                modifier = Modifier.weight(1f),
            )
            Switch(checked = auto, onCheckedChange = { auto = it })
            Text("Conectar al abrir", color = Pal.Ink)
        }
        error?.let { Text(it, color = Pal.Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
        Button(
            onClick = {
                val new = st.copy(
                    enabled = enabled,
                    name = name.trim(),
                    model = model.trim(),
                    source = source,
                    host = host.trim(),
                    port = port.trim().toIntOrNull() ?: -1,
                    pollMs = poll.trim().toLongOrNull() ?: -1,
                    divisionKg = d(division) ?: -1.0,
                    minLoadKg = d(minLoad) ?: -1.0,
                    zeroBandKg = d(zeroBand) ?: -1.0,
                    stableSamples = samples.trim().toIntOrNull() ?: -1,
                    unloadConfirmMs = unloadMs.trim().toLongOrNull() ?: -1,
                    weightMode = mode,
                    autoConnect = auto,
                    captureOnStable = onStable,
                    stableHoldMs = holdMs.trim().toLongOrNull() ?: -1,
                )
                error = vm.saveScaleSettings(new)
            },
            modifier = Modifier.padding(top = 8.dp).height(52.dp),
        ) { Text("Guardar ${name.ifBlank { "balanza ${st.scaleId}" }}", fontSize = 17.sp) }
    }
}

@Composable
private fun BasketsCard(baskets: List<Basket>, vm: PesosViewModel) {
    var name by remember { mutableStateOf("") }
    var tare by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Panel(Modifier.fillMaxWidth().widthIn(max = 900.dp)) {
        Text("Canastas (tara)", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
        Text("Lista común para ambas balanzas. La tara elegida se descuenta del peso bruto.", fontSize = 14.sp, color = Pal.Muted)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            baskets.forEach { b ->
                OutlinedButton(onClick = { vm.deleteBasket(b) }) {
                    Text("${b.name} (${Fmt.kg(b.tareKg, 1)} kg)  ✕", fontSize = 15.sp)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Field("Nombre de la canasta", name, Modifier.weight(2f)) { name = it }
            Field("Tara (kg)", tare, Modifier.weight(1f), KeyboardType.Decimal) { tare = it }
            Button(onClick = {
                error = vm.addBasket(name, tare.trim().replace(',', '.').toDoubleOrNull())
                if (error == null) { name = ""; tare = "" }
            }, modifier = Modifier.height(52.dp)) { Text("Agregar") }
        }
        error?.let { Text(it, color = Pal.Red, fontWeight = FontWeight.Bold) }
        Text("Toque una canasta para eliminarla de la lista (las pesadas ya guardadas no cambian).", fontSize = 13.sp, color = Pal.Muted)
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    modifier: Modifier,
    type: KeyboardType = KeyboardType.Text,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        modifier = modifier,
    )
}

// ============================ Prueba de conexión ============================

@Composable
fun DiagnosticsScreen(s: UiState, vm: PesosViewModel) {
    val clipboard = LocalClipboardManager.current
    val su = s.scale(s.diagScale)
    val st = su.settings
    val connected = su.link is LinkState.Connected
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Prueba de conexión MT-SICS", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                Picker(
                    label = "Balanza",
                    current = st.name,
                    options = s.scales,
                    text = { "${it.settings.name}  (${it.settings.host.ifBlank { "sin IP" }})" },
                    onPick = { vm.setDiagScale(it.id) },
                    modifier = Modifier.widthIn(min = 220.dp),
                )
            }
            Text(
                "1. Cierre la página web de ESTE ACT350 en el navegador (el equipo admite una sola conexión).\n" +
                    "2. Pulse Conectar y luego Enviar SIX1.\n" +
                    "3. Pulse Copiar resultado y envíelo para validar la lectura.\n" +
                    "Requiere firmware V1.05.0012 o superior (compruébelo con I3). Solo se envían consultas, nunca órdenes.",
                color = Pal.Ink, fontSize = 16.sp,
            )
            if (st.simulated) {
                Text("Esta balanza está en modo SIMULADOR: las respuestas no vienen del equipo real.", color = Pal.Amber, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LinkPill(su.link)
                Text(if (st.simulated) "Simulador" else "${st.host.ifBlank { "IP sin configurar" }}:${st.port}", color = Pal.Muted)
            }
            (su.link as? LinkState.Retrying)?.let { Text(it.reason, color = Pal.Red) }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (su.link == LinkState.Disconnected) Button(onClick = { vm.connect(su.id) }) { Text("Conectar") }
                else OutlinedButton(onClick = { vm.disconnect(su.id) }) { Text("Desconectar") }
                Button(onClick = { vm.sendDiag(su.id, "SIX1") }, enabled = connected) { Text("Enviar SIX1") }
                OutlinedButton(onClick = { vm.sendDiag(su.id, "I3") }, enabled = connected) { Text("I3 firmware") }
                OutlinedButton(onClick = { vm.sendDiag(su.id, "I4") }, enabled = connected) { Text("I4 n° de serie") }
                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(vm.diagText(su.id))) },
                    enabled = su.diag.isNotEmpty(),
                ) { Text("Copiar resultado") }
            }
        }
        Panel(Modifier.fillMaxWidth()) {
            Text("Última respuesta del sondeo automático", fontWeight = FontWeight.Bold, color = Pal.Ink)
            Text(su.lastRaw?.let { SicsParser.visible(it) } ?: "—", fontFamily = Digits, color = Pal.Ink)
        }
        su.diag.forEach { d ->
            Panel(Modifier.fillMaxWidth()) {
                Text("${Fmt.dateTime(d.atMs)}  Enviado: ${d.command}\\r\\n", color = Pal.Muted)
                Text("Recibido: ${SicsParser.visible(d.raw)}", fontFamily = Digits, color = Pal.Ink, fontSize = 16.sp)
                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Pal.Line)
                d.table.forEach { (k, v) ->
                    Row {
                        Text(k, Modifier.width(200.dp), color = Pal.Muted)
                        Text(v, fontFamily = Digits, color = Pal.Ink, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ============================ Diálogos ============================

@Composable
fun Dialogs(s: UiState, vm: PesosViewModel) {
    val ctx = LocalContext.current
    var pendingSave by remember { mutableStateOf<File?>(null) }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val f = pendingSave
        if (uri != null && f != null) vm.saveReportTo(uri, f)
    }
    val saveXlsx = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(PesosViewModel.XLSX_MIME)) { uri ->
        val f = pendingSave
        if (uri != null && f != null) vm.saveReportTo(uri, f)
    }

    when (val d = s.dialog) {
        null -> Unit
        is DialogState.ElementForm -> ElementFormDialog(d, s, vm)
        is DialogState.SwitchWithLoad -> {
            val dec = s.scale(d.scaleId).settings.decimals
            AlertDialog(
                onDismissRequest = { vm.dismissDialog() },
                title = { Text("Hay una carga en la balanza") },
                text = {
                    Text(
                        d.maxStableKg?.let {
                            "La carga actual (máximo estable ${Fmt.kg(it, dec)} kg) todavía no se registró. " +
                                "¿Se guarda en ${d.from.name} o pasa a ${d.to.name}?"
                        } ?: "La carga actual aún no tiene peso estable. Si cambia a ${d.to.name}, se registrará allí al retirarla.",
                    )
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") }
                        if (d.maxStableKg != null) {
                            TextButton(onClick = { vm.doSelect(d.scaleId, d.to, PendingLoad.SAVE_TO_PREVIOUS) }) {
                                Text("Guardar en ${d.from.name}")
                            }
                        }
                        Button(onClick = { vm.doSelect(d.scaleId, d.to, PendingLoad.MOVE_TO_NEW) }) { Text("Pasar a ${d.to.name}") }
                    }
                },
            )
        }
        is DialogState.ConfirmClear -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text("Borrar registros de ${d.element.name}") },
            text = { Text("Se borrarán las ${d.count} pesadas de este elemento en ${s.scale(d.scaleId).settings.name}. No se puede deshacer.") },
            confirmButton = {
                Button(onClick = { vm.clearElement(d.scaleId, d.element) }, colors = ButtonDefaults.buttonColors(containerColor = Pal.Red)) {
                    Text("Borrar")
                }
            },
            dismissButton = { TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") } },
        )
        is DialogState.ConfirmDeleteElement -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text("Eliminar ${d.element.name}") },
            text = { Text("Se eliminará el elemento con sus ${d.element.count} pesadas. No se puede deshacer.") },
            confirmButton = {
                Button(onClick = { vm.deleteElement(d.scaleId, d.element) }, colors = ButtonDefaults.buttonColors(containerColor = Pal.Red)) {
                    Text("Eliminar")
                }
            },
            dismissButton = { TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") } },
        )
        is DialogState.EditCapture -> EditCaptureDialog(d, s, vm)
        is DialogState.ReportReady -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text(d.title) },
            text = { Text("Archivo: ${d.file.name}") },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { vm.dismissDialog() }) { Text("Cerrar") }
                    TextButton(onClick = { openFile(ctx, d.file, d.mime) }) { Text("Abrir") }
                    TextButton(onClick = {
                        pendingSave = d.file
                        if (d.mime == PesosViewModel.XLSX_MIME) saveXlsx.launch(d.file.name) else savePdf.launch(d.file.name)
                    }) { Text("Guardar en…") }
                    Button(onClick = { shareFile(ctx, d.file, d.mime) }) { Text("Compartir") }
                }
            },
        )
    }
}

@Composable
private fun ElementFormDialog(d: DialogState.ElementForm, s: UiState, vm: PesosViewModel) {
    val ex = d.existing
    val scaleName = s.scale(d.scaleId).settings.name
    val suggestion = "Prueba ${(s.scale(d.scaleId).elements.size) + 1}"
    var name by remember(d) { mutableStateOf(ex?.name ?: suggestion) }
    var lote by remember(d) { mutableStateOf(ex?.lote ?: "") }
    var pieces by remember(d) { mutableStateOf((ex?.samplePieces ?: 10).toString()) }
    var error by remember(d) { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { vm.dismissDialog() },
        title = { Text(if (ex == null) "Nuevo elemento en $scaleName" else "Editar ${ex.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Nombre (modelo o prueba)", name, Modifier.fillMaxWidth()) { name = it }
                Field("Lote de fabricación (opcional)", lote, Modifier.fillMaxWidth()) { lote = it }
                Field("Piezas por muestra", pieces, Modifier.fillMaxWidth(), KeyboardType.Number) { pieces = it }
                Text(
                    "Total unidades = neto × piezas por muestra ÷ peso de la muestra. " +
                        "Este elemento solo aparece en $scaleName.",
                    fontSize = 13.sp, color = Pal.Muted,
                )
                error?.let { Text(it, color = Pal.Red, fontWeight = FontWeight.Bold) }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (ex != null) {
                    TextButton(onClick = { vm.requestDeleteElement(d.scaleId, ex) }) { Text("Eliminar", color = Pal.Red) }
                }
                TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") }
                Button(onClick = { error = vm.saveElement(d.scaleId, ex, name, lote, pieces.trim().toIntOrNull()) }) {
                    Text(if (ex == null) "Crear y seleccionar" else "Guardar")
                }
            }
        },
    )
}

@Composable
private fun EditCaptureDialog(d: DialogState.EditCapture, s: UiState, vm: PesosViewModel) {
    val w = d.weighing
    val dec = s.scale(d.scaleId).settings.decimals
    var basket by remember(d) { mutableStateOf(s.baskets.firstOrNull { it.name == w.basket && it.tareKg == w.tareKg }) }
    var keepOld by remember(d) { mutableStateOf(w.basket != null && basket == null) }
    var sample by remember(d) { mutableStateOf(w.sampleKg?.toString() ?: "") }
    val sampleKg = sample.trim().replace(',', '.').toDoubleOrNull()
    val tare = if (keepOld) w.tareKg else basket?.tareKg ?: 0.0
    val net = w.kg - tare
    val units = Units.of(net, d.element.samplePieces, sampleKg)

    AlertDialog(
        onDismissRequest = { vm.dismissDialog() },
        title = { Text("Pesada N° ${w.seq} de ${d.element.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${Fmt.dateTime(w.atMs)}   Registrado: ${Fmt.kg(w.kg, dec)} kg (${w.mode.label.lowercase()})", color = Pal.Ink)
                Picker(
                    label = "Canasta (tara)",
                    current = if (keepOld) "${w.basket} (${Fmt.kg(w.tareKg, 1)} kg)" else basket?.name ?: "Sin canasta",
                    options = listOf<Basket?>(null) + s.baskets,
                    text = { b -> b?.let { "${it.name}  (${Fmt.kg(it.tareKg, 1)} kg)" } ?: "Sin canasta (tara 0)" },
                    onPick = { basket = it; keepOld = false },
                    modifier = Modifier.fillMaxWidth(),
                )
                Field("Peso de la muestra (kg)", sample, Modifier.fillMaxWidth(), KeyboardType.Decimal) { sample = it }
                Text(
                    "Neto ${Fmt.kg(net, dec)} kg   Piezas por muestra ${d.element.samplePieces}   " +
                        "Unidades ${units?.let { Fmt.units(it) } ?: "—"}",
                    fontWeight = FontWeight.Bold, color = Pal.Ink,
                )
                Text("ID: ${w.cycleId}", fontSize = 12.sp, color = Pal.Muted)
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = { vm.deleteCapture(d.scaleId, w) }) { Text("Eliminar pesada", color = Pal.Red) }
                TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") }
                Button(
                    onClick = {
                        val b = if (keepOld) Basket(0, w.basket ?: "", w.tareKg) else basket
                        vm.saveCapture(d.scaleId, w, b, sampleKg)
                    },
                    enabled = sample.isBlank() || (sampleKg != null && sampleKg > 0),
                ) { Text("Guardar") }
            }
        },
    )
}
