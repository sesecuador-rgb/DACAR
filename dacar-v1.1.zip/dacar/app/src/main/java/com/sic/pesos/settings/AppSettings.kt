package com.sic.pesos.settings

import android.content.Context
import com.sic.pesos.cycle.CycleConfig
import com.sic.pesos.data.WeightMode
import java.math.BigDecimal

enum class LinkSource(val label: String) {
    ACT350("ACT350, MT-SICS por TCP"),
    SIMULATOR("Simulador (pesos de prueba)"),
}

/** Configuración de UNA balanza. La balanza 1 conserva las claves y la IP que ya usaba la app. */
data class Settings(
    val scaleId: Int = 1,
    val enabled: Boolean = true,
    val name: String = "Balanza $scaleId",
    val model: String = "Mettler Toledo ACT350",
    val source: LinkSource = LinkSource.ACT350,
    /** Balanza 1: IP ya validada. Balanza 2: vacía hasta que se configure (no se inventa). */
    val host: String = if (scaleId == 1) "192.168.0.10" else "",
    val port: Int = 81,
    val pollMs: Long = 100,
    val divisionKg: Double = if (scaleId == 1) 0.01 else 0.1,
    val minLoadKg: Double = if (scaleId == 1) 0.2 else 2.0,
    val zeroBandKg: Double = if (scaleId == 1) 0.05 else 0.5,
    val stableSamples: Int = 1,
    val unloadConfirmMs: Long = 800,
    val weightMode: WeightMode = WeightMode.GROSS,
    val autoConnect: Boolean = true,
    /** Guardar la pesada en cuanto se estabiliza (true) o al retirar la carga (false). */
    val captureOnStable: Boolean = true,
    val stableHoldMs: Long = 800,
) {
    val simulated: Boolean get() = source == LinkSource.SIMULATOR
    /** Hay con qué conectarse: simulador, o ACT350 con IP escrita. */
    val configured: Boolean get() = simulated || host.isNotBlank()

    fun cycleConfig() = CycleConfig(
        divisionKg = divisionKg,
        minLoadKg = minLoadKg,
        zeroBandKg = zeroBandKg,
        stableSamples = stableSamples,
        stableToleranceKg = divisionKg,
        unloadConfirmMs = unloadConfirmMs,
        captureOnStable = captureOnStable,
        stableHoldMs = stableHoldMs,
    )

    /** Decimales a mostrar según la división (0.01 → 2, 0.5 → 1, 1 → 0). */
    val decimals: Int
        get() = runCatching {
            BigDecimal(divisionKg.toString()).stripTrailingZeros().scale().coerceIn(0, 4)
        }.getOrDefault(2)

    fun validate(): String? = when {
        name.isBlank() -> "Escriba el nombre de la balanza"
        enabled && source == LinkSource.ACT350 && host.isBlank() -> "Escriba la IP del controlador de $name"
        enabled && source == LinkSource.ACT350 && !isIpv4(host.trim()) -> "La IP '$host' no es válida (ejemplo: 192.168.0.11)"
        port !in 1..65535 -> "Puerto no válido"
        pollMs < 100 -> "El intervalo de consulta debe ser de al menos 100 ms"
        else -> cycleConfig().validate()
    }

    fun withSuggestedThresholds(): Settings {
        val s = CycleConfig.suggested(divisionKg)
        return copy(
            minLoadKg = s.minLoadKg,
            zeroBandKg = s.zeroBandKg,
            stableSamples = s.stableSamples,
            unloadConfirmMs = s.unloadConfirmMs,
        )
    }

    companion object {
        fun isIpv4(s: String): Boolean {
            val parts = s.split(".")
            return parts.size == 4 && parts.all { p -> p.isNotEmpty() && p.length <= 3 && p.all(Char::isDigit) && p.toInt() in 0..255 }
        }
    }
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("pesos_ajustes", Context.MODE_PRIVATE)

    /** Balanza 1 usa las claves de siempre (sin prefijo); la balanza 2 usa el prefijo "s2_". */
    private fun p(scaleId: Int) = if (scaleId == 1) "" else "s${scaleId}_"

    fun load(scaleId: Int): Settings {
        val d = Settings(scaleId = scaleId)
        if (scaleId == 1 && prefs.getInt("schema", 1) < 2) {
            // v0.2: captura más rápida. Se reemplazan los valores lentos de la v0.1.
            prefs.edit()
                .putLong("pollMs", d.pollMs)
                .putInt("stableSamples", d.stableSamples)
                .putLong("unloadConfirmMs", d.unloadConfirmMs)
                .putInt("schema", 2)
                .apply()
        }
        val k = p(scaleId)
        fun dbl(key: String, def: Double) = prefs.getFloat(k + key, def.toFloat()).toString().toDouble()
        return Settings(
            scaleId = scaleId,
            enabled = prefs.getBoolean(k + "enabled", d.enabled),
            name = prefs.getString(k + "name", d.name) ?: d.name,
            model = prefs.getString(k + "model", d.model) ?: d.model,
            source = runCatching { LinkSource.valueOf(prefs.getString(k + "source", d.source.name)!!) }
                .getOrDefault(d.source),
            host = prefs.getString(k + "host", d.host) ?: d.host,
            port = prefs.getInt(k + "port", d.port),
            pollMs = prefs.getLong(k + "pollMs", d.pollMs),
            divisionKg = dbl("divisionKg", d.divisionKg),
            minLoadKg = dbl("minLoadKg", d.minLoadKg),
            zeroBandKg = dbl("zeroBandKg", d.zeroBandKg),
            stableSamples = prefs.getInt(k + "stableSamples", d.stableSamples),
            unloadConfirmMs = prefs.getLong(k + "unloadConfirmMs", d.unloadConfirmMs),
            weightMode = runCatching { WeightMode.valueOf(prefs.getString(k + "weightMode", d.weightMode.name)!!) }
                .getOrDefault(d.weightMode),
            autoConnect = prefs.getBoolean(k + "autoConnect", d.autoConnect),
            captureOnStable = prefs.getBoolean(k + "captureOnStable", d.captureOnStable),
            stableHoldMs = prefs.getLong(k + "stableHoldMs", d.stableHoldMs),
        )
    }

    fun save(s: Settings) {
        val k = p(s.scaleId)
        prefs.edit()
            .putBoolean(k + "enabled", s.enabled)
            .putString(k + "name", s.name.trim())
            .putString(k + "model", s.model.trim())
            .putString(k + "source", s.source.name)
            .putString(k + "host", s.host.trim())
            .putInt(k + "port", s.port)
            .putLong(k + "pollMs", s.pollMs)
            .putFloat(k + "divisionKg", s.divisionKg.toFloat())
            .putFloat(k + "minLoadKg", s.minLoadKg.toFloat())
            .putFloat(k + "zeroBandKg", s.zeroBandKg.toFloat())
            .putInt(k + "stableSamples", s.stableSamples)
            .putLong(k + "unloadConfirmMs", s.unloadConfirmMs)
            .putString(k + "weightMode", s.weightMode.name)
            .putBoolean(k + "autoConnect", s.autoConnect)
            .putBoolean(k + "captureOnStable", s.captureOnStable)
            .putLong(k + "stableHoldMs", s.stableHoldMs)
            .apply()
    }

    fun selectedElement(scaleId: Int): Long? =
        prefs.getLong("sel_element_$scaleId", -1L).takeIf { it > 0 }

    fun setSelectedElement(scaleId: Int, id: Long?) {
        prefs.edit().putLong("sel_element_$scaleId", id ?: -1L).apply()
    }

    fun selectedBasket(scaleId: Int): Long? =
        prefs.getLong("sel_basket_$scaleId", -1L).takeIf { it > 0 }

    fun setSelectedBasket(scaleId: Int, id: Long?) {
        prefs.edit().putLong("sel_basket_$scaleId", id ?: -1L).apply()
    }

    /** Solo la primera vez tras actualizar desde la v0.2: se recupera la prueba que estaba abierta. */
    fun takeLegacySelectionFlag(): Boolean {
        val pending = !prefs.getBoolean("legacy_selection_done", false)
        if (pending) prefs.edit().putBoolean("legacy_selection_done", true).apply()
        return pending
    }
}
