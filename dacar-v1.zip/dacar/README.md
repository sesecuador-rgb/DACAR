# Dacar

App independiente basada en Pesos v0.3 (dos balanzas). Se instala junto a Pesos sin reemplazarla: paquete com.sic.dacar.
No use Dacar y Pesos conectadas al mismo tiempo al mismo ACT350: el equipo admite una sola conexión.


App Android (tablet Samsung) que registra automáticamente pesadas de un
Mettler Toledo ACT350 EtherNet/IP por TCP/IP MT-SICS (puerto 81), sin internet y sin PLC.

## Estructura

| Componente | Archivo | Qué hace |
|---|---|---|
| Lector MT-SICS | `sics/SicsParser.kt`, `sics/SicsClient.kt` | Socket TCP, envía `SIX1` + CR LF, interpreta Sts, G, N, T y unidad por posición (manual 30303895, apéndice B), reconecta sola |
| Detección de ciclos | `cycle/CycleDetector.kt`, `cycle/WeighingSession.kt` | Máximo estable por ciclo, cierre al volver cerca de cero, umbrales configurables |
| Almacenamiento | `data/PesosDb.kt` | SQLite local; `cycle_id` único evita duplicados |
| Reporte | `report/PdfReport.kt` | PDF sin gráfica: identificación, tabla, cantidad y suma |
| Pantallas | `ui/` | Pesaje, Historial, Prueba de conexión, Ajustes |
| Pruebas | `app/src/test/` | Secuencias 5→7→20, 7 kg siguiente, inestables, reconexión, etc. |

## Obtener el APK (GitHub)

1. Copie la carpeta `pesos` dentro de su carpeta `SIC`.
2. Cree el repositorio `pesos` en GitHub y súbalo:
   ```
   cd SIC/pesos
   git init
   git add .
   git commit -m "Pesos v0.1"
   git branch -M main
   git remote add origin https://github.com/sesecuador-rgb/pesos.git
   git push -u origin main
   ```
3. En GitHub, pestaña **Actions**: espere el círculo verde de “Compilar APK de prueba” (5–8 min).
   Este paso ejecuta primero las pruebas de la lógica; si alguna falla, no se genera APK.
4. En **Releases → Pesos - APK de prueba** está `Pesos-prueba.apk`.

## Instalar en la tablet Samsung

1. Abra el enlace del Release en Chrome de la tablet y descargue `Pesos-prueba.apk`.
2. Ábralo desde Descargas. Si Android lo pide, permita **Instalar apps desconocidas** para Chrome
   (Ajustes → Aplicaciones → Chrome → Instalar apps desconocidas).
3. Si Play Protect avisa, elija **Más detalles → Instalar de todas formas** (es un APK de prueba sin publicar).
4. Las versiones nuevas se instalan encima sin perder las pruebas guardadas (misma llave de firma).

## Primera puesta en marcha (validación obligatoria)

1. Cierre la página web del ACT350 en todos los navegadores.
2. Abra Pesos → **Prueba de conexión** → **Conectar** → **Enviar SIX1**, **I3** e **I4**.
3. Pulse **Copiar resultado** y envíe el texto: con esa respuesta real se confirma el formato
   antes de usar la app en producción.

## Versión 0.3: dos balanzas

- **Lectura:** cada balanza tiene su propio lector MT-SICS (socket TCP, puerto 81, `SIX1`) y su propia lógica de captura. Si una se desconecta, la otra sigue leyendo y registrando.
- **Solo lectura:** la app envía únicamente `SIX1`, `I3` e `I4`, y bloquea cualquier otro comando. No toca el PLC.
- **Elementos:** cada balanza tiene su propia lista de elementos (nombre, lote y piezas por muestra). La canasta elegida define la tara.
- **Muestra:** al tocar una pesada se escribe el peso de la muestra. Las unidades se calculan como neto × piezas ÷ peso de la muestra.
- **Historial:** filtros combinables por balanza, fechas y elemento, con exportación a PDF y Excel.
- **Base de datos:** migración de la versión 1 a la 2 que solo agrega columnas. Antes de migrar se guarda una copia en `files/respaldos`.

### Configurar la balanza 2

1. Asigna al segundo ACT350 una IP única desde su panel. Por ejemplo, si la balanza 1 es 192.168.0.10, puede ser 192.168.0.11; la IP de la balanza 2 no puede repetirse.
2. En la app, ve a **Ajustes → Balanza 2** y completa: Lectura "ACT350, MT-SICS por TCP", la IP, puerto 81 y la división. Luego toca **Guardar**.
3. Ve a **Prueba de conexión**, elige Balanza 2 y envía **Enviar SIX1** e **I3**. Antes, cierra la página web de ese equipo.
4. Mientras no tengas la IP, puedes elegir Lectura "Simulador". Las pesadas quedan marcadas SIMULADO.
