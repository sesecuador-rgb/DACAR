package com.sic.pesos.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.time.ZoneId

/**
 * Almacenamiento local persistente (SQLite dentro de la tablet).
 *
 * Versión 1 (app v0.1/v0.2): tests + weighings.
 * Versión 2 (app v0.3): se AGREGAN columnas (balanza, nombre de elemento, lote, piezas de muestra,
 * unidad, tara de canasta, peso de muestra, estado…) y la tabla de canastas. No se borra ni se
 * reescribe ningún registro existente: todo lo anterior queda como elementos de la balanza 1.
 * Antes de migrar se guarda una copia del archivo en files/respaldos (ver [DbBackup]).
 *
 * La columna cycle_id es UNIQUE: aunque un ciclo se intente guardar dos veces
 * (reconexión, reintento), solo queda una pesada.
 */
class PesosDb(context: Context) :
    SQLiteOpenHelper(context.applicationContext, NAME, null, VERSION), WeighingStore {

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    /** Instalación nueva: se crea el esquema v1 y se le aplica la misma migración que a una actualización. */
    override fun onCreate(db: SQLiteDatabase) {
        createV1(db)
        upgradeToV2(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) upgradeToV2(db)
    }

    // ---------- Elementos / pruebas ----------

    fun createElement(
        scaleId: Int, name: String, lote: String, samplePieces: Int, mode: WeightMode, now: Long,
    ): TestRecord {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val next = db.rawQuery("SELECT COALESCE(MAX(number),0)+1 FROM tests", null)
                .use { it.moveToFirst(); it.getInt(0) }
            val id = db.insertOrThrow("tests", null, ContentValues().apply {
                put("number", next)
                put("started_at", now)
                put("mode", mode.name)
                put("scale_id", scaleId)
                put("name", name)
                put("lote", lote)
                put("sample_pieces", samplePieces)
            })
            db.setTransactionSuccessful()
            return TestRecord(
                id, next, now, null, mode, scaleId = scaleId, name = name, lote = lote, samplePieces = samplePieces,
            )
        } finally {
            db.endTransaction()
        }
    }

    fun updateElement(id: Long, name: String, lote: String, samplePieces: Int) {
        writableDatabase.update("tests", ContentValues().apply {
            put("name", name)
            put("lote", lote)
            put("sample_pieces", samplePieces)
        }, "id=?", arrayOf(id.toString()))
    }

    fun elements(scaleId: Int): List<TestRecord> =
        queryTests("WHERE t.scale_id=?", arrayOf(scaleId.toString()))

    fun allElements(): List<TestRecord> = queryTests("", null)

    fun getTest(testId: Long): TestRecord? =
        queryTests("WHERE t.id=?", arrayOf(testId.toString())).firstOrNull()

    /** Prueba que quedó abierta en la v0.2: se selecciona en la balanza 1 tras actualizar. */
    fun legacyOpenTest(): TestRecord? =
        queryTests("WHERE t.finished_at IS NULL AND t.scale_id = 1", null).firstOrNull()

    fun deleteTest(testId: Long) {
        writableDatabase.delete("tests", "id=?", arrayOf(testId.toString()))
    }

    private fun queryTests(where: String, args: Array<String>?): List<TestRecord> =
        readableDatabase.rawQuery(
            """SELECT t.id, t.number, t.started_at, t.finished_at, t.mode,
                      COUNT(w.id), COALESCE(SUM(w.weight_kg),0), COALESCE(SUM(w.weight_kg - w.tare_kg),0),
                      t.scale_id, t.name, t.lote, t.sample_pieces
               FROM tests t LEFT JOIN weighings w ON w.test_id = t.id
               $where
               GROUP BY t.id ORDER BY t.started_at DESC""",
            args
        ).use { c ->
            val out = ArrayList<TestRecord>()
            while (c.moveToNext()) {
                out += TestRecord(
                    id = c.getLong(0),
                    number = c.getInt(1),
                    startedAt = c.getLong(2),
                    finishedAt = if (c.isNull(3)) null else c.getLong(3),
                    mode = modeOf(c.getString(4)),
                    count = c.getInt(5),
                    totalKg = c.getDouble(6),
                    totalNetKg = c.getDouble(7),
                    scaleId = c.getInt(8),
                    name = c.getString(9),
                    lote = c.getString(10),
                    samplePieces = c.getInt(11),
                )
            }
            out
        }

    // ---------- Pesadas ----------

    fun weighings(testId: Long): List<Weighing> =
        readableDatabase.rawQuery(
            "SELECT $W_COLS FROM weighings w WHERE w.test_id=? ORDER BY w.seq",
            arrayOf(testId.toString())
        ).use { c ->
            val out = ArrayList<Weighing>()
            while (c.moveToNext()) out += readWeighing(c)
            out
        }

    /** Vacía las pesadas de un elemento; la numeración vuelve a 1. */
    fun clearWeighings(testId: Long) {
        writableDatabase.delete("weighings", "test_id=?", arrayOf(testId.toString()))
    }

    override fun saveWeighing(testId: Long, cycleId: String, kg: Double, atMs: Long, info: CaptureInfo): Weighing? {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val exists = db.rawQuery("SELECT 1 FROM weighings WHERE cycle_id=?", arrayOf(cycleId))
                .use { it.moveToFirst() }
            if (exists) return null
            val seq = db.rawQuery(
                "SELECT COALESCE(MAX(seq),0)+1 FROM weighings WHERE test_id=?", arrayOf(testId.toString())
            ).use { it.moveToFirst(); it.getInt(0) }
            val id = db.insertWithOnConflict("weighings", null, ContentValues().apply {
                put("test_id", testId)
                put("seq", seq)
                put("weight_kg", kg)
                put("at_ms", atMs)
                put("cycle_id", cycleId)
                put("scale_id", info.scaleId)
                put("unit", info.unit)
                put("tare_kg", info.tareKg)
                put("basket", info.basket)
                put("status", info.status)
                put("mode", info.mode.name)
                if (info.indicatorTareKg != null) put("indicator_tare_kg", info.indicatorTareKg)
                else putNull("indicator_tare_kg")
            }, SQLiteDatabase.CONFLICT_IGNORE)
            if (id == -1L) return null
            db.setTransactionSuccessful()
            return Weighing(
                id, testId, seq, kg, atMs, cycleId, info.scaleId, info.unit, info.tareKg, info.basket,
                null, info.status, info.mode, info.indicatorTareKg,
            )
        } finally {
            db.endTransaction()
        }
    }

    /** Cambia la canasta (tara) o el peso de la muestra de una pesada ya guardada. */
    fun updateCapture(weighingId: Long, basket: String?, tareKg: Double, sampleKg: Double?) {
        writableDatabase.update("weighings", ContentValues().apply {
            put("basket", basket)
            put("tare_kg", tareKg)
            if (sampleKg != null) put("sample_kg", sampleKg) else putNull("sample_kg")
        }, "id=?", arrayOf(weighingId.toString()))
    }

    fun deleteCapture(weighingId: Long) {
        writableDatabase.delete("weighings", "id=?", arrayOf(weighingId.toString()))
    }

    // ---------- Historial ----------

    fun query(filter: HistoryFilter, zone: ZoneId = ZoneId.systemDefault()): List<CaptureRecord> {
        val (where, args) = filter.toSql(zone)
        return readableDatabase.rawQuery(
            """SELECT $W_COLS, t.name, t.lote, t.sample_pieces
               FROM weighings w JOIN tests t ON t.id = w.test_id
               $where
               ORDER BY w.at_ms, w.scale_id, w.seq""",
            args
        ).use { c ->
            val out = ArrayList<CaptureRecord>()
            while (c.moveToNext()) {
                out += CaptureRecord(readWeighing(c), c.getString(14), c.getString(15), c.getInt(16))
            }
            out
        }
    }

    // ---------- Canastas ----------

    fun baskets(): List<Basket> =
        readableDatabase.rawQuery("SELECT id, name, tare_kg FROM baskets ORDER BY tare_kg, name", null).use { c ->
            val out = ArrayList<Basket>()
            while (c.moveToNext()) out += Basket(c.getLong(0), c.getString(1), c.getDouble(2))
            out
        }

    fun addBasket(name: String, tareKg: Double): Basket {
        val id = writableDatabase.insertOrThrow("baskets", null, ContentValues().apply {
            put("name", name)
            put("tare_kg", tareKg)
        })
        return Basket(id, name, tareKg)
    }

    fun deleteBasket(id: Long) {
        writableDatabase.delete("baskets", "id=?", arrayOf(id.toString()))
    }

    companion object {
        const val NAME = "pesos.db"
        const val VERSION = 2

        /** Taras que aparecen en el registro en papel; se pueden editar en Ajustes. */
        val DEFAULT_BASKETS = listOf(48.0, 55.0, 56.0, 58.0, 60.0, 64.0, 71.0)

        private const val W_COLS =
            "w.id, w.test_id, w.seq, w.weight_kg, w.at_ms, w.cycle_id, w.scale_id, w.unit, " +
                "w.tare_kg, w.basket, w.sample_kg, w.status, w.mode, w.indicator_tare_kg"

        private fun readWeighing(c: Cursor) = Weighing(
            id = c.getLong(0),
            testId = c.getLong(1),
            seq = c.getInt(2),
            kg = c.getDouble(3),
            atMs = c.getLong(4),
            cycleId = c.getString(5),
            scaleId = c.getInt(6),
            unit = c.getString(7),
            tareKg = c.getDouble(8),
            basket = if (c.isNull(9)) null else c.getString(9),
            sampleKg = if (c.isNull(10)) null else c.getDouble(10),
            status = c.getString(11),
            mode = modeOf(c.getString(12)),
            indicatorTareKg = if (c.isNull(13)) null else c.getDouble(13),
        )

        private fun modeOf(s: String?) = runCatching { WeightMode.valueOf(s!!) }.getOrDefault(WeightMode.GROSS)

        /** Esquema exacto de la app v0.1/v0.2 (base de datos versión 1). */
        fun createV1(db: SQLiteDatabase) {
            db.execSQL(
                """CREATE TABLE tests(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    number INTEGER NOT NULL,
                    started_at INTEGER NOT NULL,
                    finished_at INTEGER,
                    mode TEXT NOT NULL)"""
            )
            db.execSQL(
                """CREATE TABLE weighings(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    test_id INTEGER NOT NULL REFERENCES tests(id) ON DELETE CASCADE,
                    seq INTEGER NOT NULL,
                    weight_kg REAL NOT NULL,
                    at_ms INTEGER NOT NULL,
                    cycle_id TEXT NOT NULL UNIQUE)"""
            )
            db.execSQL("CREATE INDEX idx_weighings_test ON weighings(test_id, seq)")
        }

        /** Migración 1 → 2: solo agrega columnas y tablas. Los datos existentes no se modifican. */
        fun upgradeToV2(db: SQLiteDatabase) {
            listOf(
                "ALTER TABLE tests ADD COLUMN scale_id INTEGER NOT NULL DEFAULT 1",
                "ALTER TABLE tests ADD COLUMN name TEXT NOT NULL DEFAULT ''",
                "ALTER TABLE tests ADD COLUMN lote TEXT NOT NULL DEFAULT ''",
                "ALTER TABLE tests ADD COLUMN sample_pieces INTEGER NOT NULL DEFAULT 10",
                "UPDATE tests SET name = 'Prueba ' || number WHERE name = ''",
                "ALTER TABLE weighings ADD COLUMN scale_id INTEGER NOT NULL DEFAULT 1",
                "ALTER TABLE weighings ADD COLUMN unit TEXT NOT NULL DEFAULT 'kg'",
                "ALTER TABLE weighings ADD COLUMN tare_kg REAL NOT NULL DEFAULT 0",
                "ALTER TABLE weighings ADD COLUMN basket TEXT",
                "ALTER TABLE weighings ADD COLUMN sample_kg REAL",
                "ALTER TABLE weighings ADD COLUMN status TEXT NOT NULL DEFAULT 'ESTABLE'",
                "ALTER TABLE weighings ADD COLUMN mode TEXT NOT NULL DEFAULT 'GROSS'",
                "ALTER TABLE weighings ADD COLUMN indicator_tare_kg REAL",
                "UPDATE weighings SET mode = COALESCE((SELECT t.mode FROM tests t WHERE t.id = weighings.test_id), 'GROSS')",
                "CREATE INDEX idx_weighings_scale_time ON weighings(scale_id, at_ms)",
                "CREATE TABLE baskets(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, tare_kg REAL NOT NULL)",
            ).forEach { db.execSQL(it) }
            DEFAULT_BASKETS.forEach { tare ->
                db.insert("baskets", null, ContentValues().apply {
                    put("name", "Canasta ${tare.toInt()} kg")
                    put("tare_kg", tare)
                })
            }
        }
    }
}

/** Copia de seguridad del archivo de datos antes de migrarlo a una versión nueva. */
object DbBackup {
    fun beforeOpen(context: Context) {
        val dbFile = context.getDatabasePath(PesosDb.NAME)
        if (!dbFile.exists()) return
        val version = runCatching {
            SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READONLY).use { it.version }
        }.getOrDefault(PesosDb.VERSION)
        if (version >= PesosDb.VERSION) return
        val dir = File(context.filesDir, "respaldos").apply { mkdirs() }
        listOf("", "-wal", "-shm", "-journal").forEach { suffix ->
            val f = File(dbFile.path + suffix)
            if (f.exists()) f.copyTo(File(dir, "pesos-v$version.db$suffix"), overwrite = true)
        }
    }
}
