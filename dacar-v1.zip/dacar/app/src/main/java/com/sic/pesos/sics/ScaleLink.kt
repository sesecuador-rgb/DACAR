package com.sic.pesos.sics

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/** Fuente de lecturas de una balanza: el ACT350 real (MT-SICS por TCP) o el simulador de pruebas. */
interface ScaleLink {
    val link: StateFlow<LinkState>
    val events: SharedFlow<ClientEvent>
    val isRunning: Boolean
    fun start(host: String, port: Int, pollMs: Long)
    fun stop()
    suspend fun transact(command: String): String

    companion object {
        /**
         * La app es de SOLO LECTURA: únicamente consulta peso (SIX1), firmware (I3) y n° de serie (I4).
         * Nunca envía Z, ZI, T, TI, TA, TAC ni ningún otro comando que cambie el proceso.
         */
        val READ_ONLY_COMMANDS = setOf("SIX1", "I3", "I4")

        fun checkReadOnly(command: String) {
            if (command !in READ_ONLY_COMMANDS) {
                throw IllegalArgumentException("Comando '$command' no permitido: la app es de solo lectura")
            }
        }
    }
}
