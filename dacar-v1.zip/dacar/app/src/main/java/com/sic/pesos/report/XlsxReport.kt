package com.sic.pesos.report

import com.sic.pesos.data.CaptureRecord
import com.sic.pesos.report.XlsxWriter.Cell
import com.sic.pesos.report.XlsxWriter.Style
import java.io.OutputStream
import java.time.ZoneId

/** Reporte Excel de los registros filtrados. Sin Android: se prueba con JUnit. */
object XlsxReport {

    val HEADERS = listOf(
        "Pesada N°", "Fecha", "Hora", "Balanza", "Elemento / modelo", "Lote", "Canasta",
        "P. bruto", "Tara", "P. neto", "P. muestra", "Piezas muestra", "Total unidades",
        "Unidad", "Estado", "ID del registro",
    )

    fun build(records: List<CaptureRecord>, ctx: ReportContext): XlsxWriter.Sheet {
        val rows = mutableListOf<List<Cell>>()
        rows += listOf(Cell.Text("Reporte de pesajes", Style.TITLE))
        // Etiqueta en A (se extiende sobre B y C, vacías) y valor en D, para que se lea completa.
        fun labeled(label: String, value: Cell, bold: Boolean = true) =
            listOf(Cell.Text(label, if (bold) Style.BOLD else Style.NORMAL), Cell.Blank, Cell.Blank, value)
        rows += labeled("Generado", Cell.DateTime(ctx.generatedAt))
        ReportData.filterLines(ctx).forEach { (k, v) -> rows += labeled("Filtro: $k", Cell.Text(v)) }
        rows += emptyList<Cell>()
        rows += HEADERS.map { Cell.Text(it, Style.HEADER) }
        val headerRow = rows.size

        for (r in records) {
            val w = r.w
            val d = ctx.decimalsOf(w.scaleId)
            val gross = Fmt.round(w.kg, d)
            val tare = Fmt.round(w.tareKg, d)
            rows += listOf(
                Cell.Num(w.seq.toDouble(), Style.DEC0),
                Cell.DateTime(w.atMs, Style.DATE),
                Cell.DateTime(w.atMs, Style.TIME),
                Cell.Text(ctx.scaleName(w.scaleId)),
                Cell.Text(r.elementName),
                Cell.Text(r.lote),
                Cell.Text(w.basket ?: ""),
                Cell.Num(gross.toDouble(), Style.decimals(d)),
                Cell.Num(tare.toDouble(), Style.decimals(d)),
                Cell.Num((gross - tare).toDouble(), Style.decimals(d)),
                w.sampleKg?.let { Cell.Num(it, Style.DEC3) } ?: Cell.Blank,
                Cell.Num(r.samplePieces.toDouble(), Style.DEC0),
                r.units?.let { Cell.Num(it.toDouble(), Style.THOUSANDS) } ?: Cell.Blank,
                Cell.Text(w.unit),
                Cell.Text(w.status),
                Cell.Text(w.cycleId),
            )
        }

        rows += emptyList<Cell>()
        val decimalsOf = { id: Int -> ctx.decimalsOf(id) }
        val maxDec = records.map { ctx.decimalsOf(it.w.scaleId) }.maxOrNull() ?: 1
        fun totals(label: String, s: Summary) {
            rows += listOf(Cell.Text(label, Style.BOLD))
            rows += labeled("Cantidad de registros", Cell.Num(s.count.toDouble(), Style.DEC0), bold = false)
            s.grossByUnit.forEach { (u, v) ->
                rows += labeled("Total bruto ($u)", Cell.Num(v.toDouble(), Style.decimals(maxDec)), bold = false)
            }
            s.netByUnit.forEach { (u, v) ->
                rows += labeled("Total neto ($u)", Cell.Num(v.toDouble(), Style.decimals(maxDec)), bold = false)
            }
            s.totalUnits?.let {
                rows += labeled("Total unidades", Cell.Num(it.toDouble(), Style.THOUSANDS), bold = false)
            }
        }
        if (ReportData.includesSeveralScales(records)) {
            ReportData.perScale(records, decimalsOf).forEach { (id, s) -> totals("Subtotal ${ctx.scaleName(id)}", s) }
            rows += emptyList<Cell>()
        }
        totals("Totales", ReportData.summarize(records, decimalsOf))

        val widths = listOf(10.0, 12.0, 10.0, 16.0, 20.0, 12.0, 16.0, 11.0, 9.0, 11.0, 11.0, 9.0, 13.0, 8.0, 11.0, 38.0)
        return XlsxWriter.Sheet("Registros", rows, widths, freezeBelowRow = headerRow)
    }

    fun write(out: OutputStream, records: List<CaptureRecord>, ctx: ReportContext, zone: ZoneId = ZoneId.systemDefault()) =
        XlsxWriter.write(out, build(records, ctx), zone)
}
