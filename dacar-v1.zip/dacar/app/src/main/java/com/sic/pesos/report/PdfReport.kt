package com.sic.pesos.report

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.sic.pesos.data.CaptureRecord
import java.io.File
import java.io.FileOutputStream

/**
 * Reporte PDF A4 horizontal, con el mismo orden de columnas del registro en papel:
 * fecha, (balanza), modelo, lote, hora, canasta, bruto, tara, neto, muestra y total de unidades.
 */
object PdfReport {
    private const val W = 842
    private const val H = 595
    private const val M = 30f
    private const val ROW = 17f

    private class Col(val title: String, val width: Float, val right: Boolean = false)

    fun write(file: File, records: List<CaptureRecord>, ctx: ReportContext) {
        val several = ReportData.includesSeveralScales(records) || ctx.filter.scaleId == null
        val cols = buildList {
            add(Col("N°", 30f, right = true))
            add(Col("Fecha", 62f))
            add(Col("Hora", 52f))
            if (several) add(Col("Balanza", 80f))
            add(Col("Elemento", if (several) 100f else 140f))
            add(Col("Lote", 66f))
            add(Col("Canasta", if (several) 82f else 102f))
            add(Col("P. bruto kg", 62f, right = true))
            add(Col("Tara kg", 50f, right = true))
            add(Col("P. neto kg", 62f, right = true))
            add(Col("Muestra kg", 60f, right = true))
            add(Col("Unidades", 56f, right = true))
        }
        val tableWidth = cols.sumOf { it.width.toDouble() }.toFloat()

        val doc = PdfDocument()
        val title = Paint().apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK; isAntiAlias = true }
        val bold = Paint().apply { textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK; isAntiAlias = true }
        val body = Paint().apply { textSize = 9.5f; color = Color.BLACK; isAntiAlias = true }
        val small = Paint().apply { textSize = 8f; color = Color.DKGRAY; isAntiAlias = true }
        val line = Paint().apply { color = Color.rgb(170, 170, 170); strokeWidth = 0.6f }
        val shade = Paint().apply { color = Color.rgb(226, 233, 240) }

        var pageNo = 0
        var page: PdfDocument.Page? = null
        var c: Canvas? = null
        var y = 0f

        fun cell(text: String, x: Float, col: Col, p: Paint) {
            val t = fit(text, col.width - 6f, p)
            if (col.right) {
                c!!.drawText(t, x + col.width - 3f - p.measureText(t), y, p)
            } else {
                c!!.drawText(t, x + 3f, y, p)
            }
        }

        fun tableHeader() {
            c!!.drawRect(M, y - 12f, M + tableWidth, y + 5f, shade)
            var x = M
            cols.forEach { col -> cell(col.title, x, col, bold); x += col.width }
            y += ROW
        }

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            c = page!!.canvas
            y = M + 12f
            c!!.drawText("Reporte de pesajes", M, y, title)
            c!!.drawText("Página $pageNo", W - M - small.measureText("Página $pageNo"), y, small)
            y += 18f
            if (pageNo == 1) {
                c!!.drawText("Generado: ${Fmt.dateTime(ctx.generatedAt)}", M, y, body)
                y += 14f
                val filters = ReportData.filterLines(ctx).joinToString("     ") { (k, v) -> "$k: $v" }
                c!!.drawText("Filtros: $filters", M, y, body)
                y += 18f
            }
            tableHeader()
        }

        newPage()
        if (records.isEmpty()) {
            c!!.drawText("No hay registros para los filtros elegidos.", M, y, body)
            y += ROW
        }
        records.forEach { r ->
            if (y > H - M - 20f) newPage()
            val w = r.w
            val d = ctx.decimalsOf(w.scaleId)
            val gross = Fmt.round(w.kg, d)
            val tare = Fmt.round(w.tareKg, d)
            val values = buildList {
                add(w.seq.toString())
                add(Fmt.date(w.atMs))
                add(Fmt.time(w.atMs))
                if (several) add(ctx.scaleName(w.scaleId))
                add(r.elementName)
                add(r.lote)
                add(w.basket ?: "")
                add(gross.toPlainString())
                add(tare.toPlainString())
                add((gross - tare).toPlainString())
                add(w.sampleKg?.let { Fmt.kg(it, 3) } ?: "")
                add(r.units?.let { Fmt.units(it) } ?: "")
            }
            var x = M
            cols.forEachIndexed { i, col -> cell(values[i], x, col, body); x += col.width }
            c!!.drawLine(M, y + 5f, M + tableWidth, y + 5f, line)
            y += ROW
        }

        // Totales
        val decimalsOf = { id: Int -> ctx.decimalsOf(id) }
        val maxDec = records.map { ctx.decimalsOf(it.w.scaleId) }.maxOrNull() ?: 1
        fun summaryLines(label: String, s: Summary): List<String> = buildList {
            val parts = mutableListOf("Registros: ${s.count}")
            s.grossByUnit.forEach { (u, v) -> parts += "Bruto: ${v.setScale(maxDec).toPlainString()} $u" }
            s.netByUnit.forEach { (u, v) -> parts += "Neto: ${v.setScale(maxDec).toPlainString()} $u" }
            s.totalUnits?.let { parts += "Unidades: ${Fmt.units(it)}" }
            add("$label   " + parts.joinToString("     "))
        }
        val lines = mutableListOf<String>()
        if (ReportData.includesSeveralScales(records)) {
            ReportData.perScale(records, decimalsOf).forEach { (id, s) -> lines += summaryLines("Subtotal ${ctx.scaleName(id)}", s) }
        }
        lines += summaryLines("TOTAL", ReportData.summarize(records, decimalsOf))

        if (y + lines.size * 15f + 70f > H - M) newPage()
        y += 6f
        c!!.drawLine(M, y - 10f, M + tableWidth, y - 10f, Paint(line).apply { color = Color.BLACK; strokeWidth = 1.2f })
        lines.forEach { l -> c!!.drawText(l, M, y, bold); y += 15f }

        // Firmas, como en el registro en papel
        val sigY = (y + 45f).coerceAtMost(H - M - 12f)
        val sigW = 200f
        listOf(M + 40f to "Supervisor de área", W - M - 40f - sigW to "Asistente de producción").forEach { (x, label) ->
            c!!.drawLine(x, sigY, x + sigW, sigY, Paint(line).apply { color = Color.BLACK })
            c!!.drawText(label, x + (sigW - small.measureText(label)) / 2, sigY + 12f, small)
        }

        page?.let { doc.finishPage(it) }
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
    }

    /** Recorta el texto con "…" si no cabe en la columna. */
    private fun fit(text: String, maxWidth: Float, p: Paint): String {
        if (p.measureText(text) <= maxWidth) return text
        var end = text.length
        while (end > 0 && p.measureText(text.substring(0, end) + "…") > maxWidth) end--
        return text.substring(0, end) + "…"
    }
}
