package com.sic.pesos.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToLong

enum class WeightMode(val label: String) { GROSS("Peso bruto"), NET("Peso neto") }

/**
 * Elemento / prueba (por ejemplo "F30", lote "21-09-26"). Pertenece a UNA sola balanza.
 * Es la tabla "tests" de la v0.1/v0.2, ampliada en la v0.3 sin perder los registros anteriores.
 */
data class TestRecord(
    val id: Long,
    val number: Int,
    val startedAt: Long,
    val finishedAt: Long?,
    val mode: WeightMode,
    val count: Int = 0,
    val totalKg: Double = 0.0,
    val scaleId: Int = 1,
    val name: String = "Prueba $number",
    val lote: String = "",
    val samplePieces: Int = 10,
    val totalNetKg: Double = totalKg,
) {
    val label: String get() = if (lote.isBlank()) name else "$name (lote $lote)"
}

/** Una pesada capturada. */
data class Weighing(
    val id: Long,
    val testId: Long,
    val seq: Int,
    /** Peso registrado (bruto o neto del indicador, según el modo), en kg. */
    val kg: Double,
    /** Momento en que se alcanzó el máximo estable del ciclo. */
    val atMs: Long,
    /** Identificador único de la pesada. */
    val cycleId: String,
    val scaleId: Int = 1,
    val unit: String = "kg",
    /** Tara de la canasta elegida, en kg. */
    val tareKg: Double = 0.0,
    val basket: String? = null,
    /** Peso de la muestra de piezas, en kg (se escribe en la tablet). */
    val sampleKg: Double? = null,
    /** ESTABLE, o SIMULADO si vino del simulador de pruebas. */
    val status: String = "ESTABLE",
    val mode: WeightMode = WeightMode.GROSS,
    /** Tara que informaba el propio ACT350 (campo T de SIX1), si había. */
    val indicatorTareKg: Double? = null,
) {
    val netKg: Double get() = kg - tareKg
}

data class Basket(val id: Long, val name: String, val tareKg: Double)

/** Datos que acompañan a una pesada al guardarla. */
data class CaptureInfo(
    val scaleId: Int,
    val unit: String = "kg",
    val tareKg: Double = 0.0,
    val basket: String? = null,
    val status: String = "ESTABLE",
    val mode: WeightMode = WeightMode.GROSS,
    val indicatorTareKg: Double? = null,
)

/** Lo único que la lógica de pesaje necesita del almacenamiento. */
interface WeighingStore {
    /**
     * Guarda la pesada si ese ciclo (cycleId) aún no fue guardado.
     * Devuelve la pesada guardada, o null si ya existía (evita duplicados).
     */
    fun saveWeighing(testId: Long, cycleId: String, kg: Double, atMs: Long, info: CaptureInfo): Weighing?
}

/** Fila del historial: pesada + datos de su elemento. */
data class CaptureRecord(
    val w: Weighing,
    val elementName: String,
    val lote: String,
    val samplePieces: Int,
) {
    val units: Long? get() = Units.of(w.netKg, samplePieces, w.sampleKg)
}

object Units {
    /** Total de unidades = neto × piezas de la muestra / peso de la muestra. */
    fun of(netKg: Double, samplePieces: Int, sampleKg: Double?): Long? =
        if (sampleKg == null || sampleKg <= 0.0 || samplePieces <= 0 || netKg <= 0.0) null
        else (netKg * samplePieces / sampleKg).roundToLong()
}

/** Filtros combinables del historial. null = sin filtro. Las fechas son días locales, inclusivos. */
data class HistoryFilter(
    val scaleId: Int? = null,
    val fromDay: LocalDate? = null,
    val toDay: LocalDate? = null,
    val elementId: Long? = null,
) {
    fun fromMs(zone: ZoneId): Long? = fromDay?.atStartOfDay(zone)?.toInstant()?.toEpochMilli()
    fun toMsExclusive(zone: ZoneId): Long? = toDay?.plusDays(1)?.atStartOfDay(zone)?.toInstant()?.toEpochMilli()

    fun toSql(zone: ZoneId = ZoneId.systemDefault()): Pair<String, Array<String>> {
        val cond = mutableListOf<String>()
        val args = mutableListOf<String>()
        scaleId?.let { cond += "w.scale_id = ?"; args += it.toString() }
        fromMs(zone)?.let { cond += "w.at_ms >= ?"; args += it.toString() }
        toMsExclusive(zone)?.let { cond += "w.at_ms < ?"; args += it.toString() }
        elementId?.let { cond += "w.test_id = ?"; args += it.toString() }
        val where = if (cond.isEmpty()) "" else "WHERE " + cond.joinToString(" AND ")
        return where to args.toTypedArray()
    }

    fun matches(w: Weighing, zone: ZoneId = ZoneId.systemDefault()): Boolean {
        if (scaleId != null && w.scaleId != scaleId) return false
        fromMs(zone)?.let { if (w.atMs < it) return false }
        toMsExclusive(zone)?.let { if (w.atMs >= it) return false }
        if (elementId != null && w.testId != elementId) return false
        return true
    }

    companion object {
        fun day(ms: Long, zone: ZoneId = ZoneId.systemDefault()): LocalDate =
            Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    }
}
