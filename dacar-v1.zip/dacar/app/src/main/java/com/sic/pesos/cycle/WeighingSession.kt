package com.sic.pesos.cycle

import com.sic.pesos.data.Basket
import com.sic.pesos.data.CaptureInfo
import com.sic.pesos.data.WeighingStore
import com.sic.pesos.data.Weighing
import com.sic.pesos.data.WeightMode
import com.sic.pesos.sics.SicsParser
import com.sic.pesos.sics.SicsResponse
import com.sic.pesos.sics.WeightStatus

/**
 * Une las tres piezas de UNA balanza: respuesta MT-SICS → muestra en kg (bruto o neto) →
 * detector de ciclos → almacenamiento. Cada balanza tiene su propia sesión y su propio
 * detector, así que nada de lo que pase en una afecta a la otra. Sin Android: se prueba con JUnit.
 */
class WeighingSession(
    private val store: WeighingStore,
    val detector: CycleDetector,
    val scaleId: Int = 1,
) {
    var testId: Long? = null
        private set
    var mode: WeightMode = WeightMode.GROSS
        private set
    /** Canasta vigente: su tara se descuenta de las pesadas que se cierren a partir de ahora. */
    var basket: Basket? = null
    /** true si las lecturas vienen del simulador (las pesadas quedan marcadas SIMULADO). */
    var simulated: Boolean = false
    private var indicatorTareAtMax: Double? = null

    fun start(testId: Long, mode: WeightMode) {
        this.testId = testId
        this.mode = mode
        detector.reset()
        indicatorTareAtMax = null
    }

    /** Cambia de elemento conservando el ciclo en curso: la carga puesta se asigna al nuevo. */
    fun switchTo(testId: Long, mode: WeightMode) {
        if (this.testId == null || mode != this.mode) {
            start(testId, mode)
        } else {
            this.testId = testId
        }
    }

    fun stop() {
        testId = null
        detector.reset()
        indicatorTareAtMax = null
    }

    /** Devuelve las pesadas que quedaron guardadas con esta respuesta (0 o 1). */
    fun onResponse(timeMs: Long, response: SicsResponse): List<Weighing> {
        val id = testId ?: return emptyList()
        val events = detector.onSample(toSample(timeMs, response, mode))
        val out = mutableListOf<Weighing>()
        for (e in events) {
            when (e) {
                is CycleEvent.NewMax -> indicatorTareAtMax = indicatorTareKg(response)
                is CycleEvent.Completed -> save(id, e)?.let { out += it }
                else -> Unit
            }
        }
        return out
    }

    fun onLinkLost(timeMs: Long) {
        if (testId != null) detector.onLinkLost(timeMs)
    }

    /** Cierra el ciclo actual sin esperar la descarga. save = true guarda su máximo estable. */
    fun closeCycle(timeMs: Long, save: Boolean): Weighing? {
        val id = testId ?: return null
        val ev = detector.closeNow(timeMs)
        return if (save && ev is CycleEvent.Completed) save(id, ev) else {
            indicatorTareAtMax = null
            null
        }
    }

    private fun save(id: Long, e: CycleEvent.Completed): Weighing? {
        val b = basket
        val w = store.saveWeighing(
            id, e.cycleId, e.kg, e.maxAtMs,
            CaptureInfo(
                scaleId = scaleId,
                unit = "kg",
                tareKg = b?.tareKg ?: 0.0,
                basket = b?.name,
                status = if (simulated) "SIMULADO" else "ESTABLE",
                mode = mode,
                indicatorTareKg = indicatorTareAtMax,
            ),
        )
        indicatorTareAtMax = null
        return w
    }

    companion object {
        fun toSample(timeMs: Long, response: SicsResponse, mode: WeightMode): WeightSample {
            val r = (response as? SicsResponse.Six1)?.reading
                ?: return WeightSample(timeMs, SampleKind.INVALID, null)
            val kind = when (r.status) {
                WeightStatus.STABLE -> SampleKind.STABLE
                WeightStatus.DYNAMIC -> SampleKind.DYNAMIC
                WeightStatus.OVERLOAD -> SampleKind.OVERLOAD
                WeightStatus.UNDERLOAD -> SampleKind.UNDERLOAD
                else -> SampleKind.INVALID
            }
            val value = if (mode == WeightMode.GROSS) r.gross else r.net
            val kg = if (r.complete && value != null) SicsParser.toKg(value, r.unit!!) else null
            val finalKind = if (kg == null && (kind == SampleKind.STABLE || kind == SampleKind.DYNAMIC)) {
                SampleKind.INVALID
            } else kind
            return WeightSample(timeMs, finalKind, kg)
        }

        private fun indicatorTareKg(response: SicsResponse): Double? {
            val r = (response as? SicsResponse.Six1)?.reading ?: return null
            val t = r.tare ?: return null
            val u = r.unit ?: return null
            return SicsParser.toKg(t, u)
        }
    }
}
