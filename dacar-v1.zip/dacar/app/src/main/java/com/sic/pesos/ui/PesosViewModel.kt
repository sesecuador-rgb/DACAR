package com.sic.pesos.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sic.pesos.cycle.CycleDetector
import com.sic.pesos.cycle.CyclePhase
import com.sic.pesos.cycle.CycleSnapshot
import com.sic.pesos.cycle.WeighingSession
import com.sic.pesos.data.Basket
import com.sic.pesos.data.CaptureRecord
import com.sic.pesos.data.DbBackup
import com.sic.pesos.data.HistoryFilter
import com.sic.pesos.data.PesosDb
import com.sic.pesos.data.TestRecord
import com.sic.pesos.data.Weighing
import com.sic.pesos.report.Fmt
import com.sic.pesos.report.PdfReport
import com.sic.pesos.report.ReportContext
import com.sic.pesos.report.XlsxReport
import com.sic.pesos.settings.AppSettings
import com.sic.pesos.settings.LinkSource
import com.sic.pesos.settings.Settings
import com.sic.pesos.sics.ClientEvent
import com.sic.pesos.sics.LinkState
import com.sic.pesos.sics.ScaleLink
import com.sic.pesos.sics.SicsClient
import com.sic.pesos.sics.SicsParser
import com.sic.pesos.sics.SicsResponse
import com.sic.pesos.sics.SimulatedScale
import com.sic.pesos.sics.Six1Reading
import com.sic.pesos.sics.WeightStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

enum class Screen { MAIN, HISTORY, SETTINGS, DIAGNOSTICS }

enum class PendingLoad { SAVE_TO_PREVIOUS, MOVE_TO_NEW }

sealed class DialogState {
    data class ElementForm(val scaleId: Int, val existing: TestRecord?) : DialogState()
    data class SwitchWithLoad(val scaleId: Int, val from: TestRecord, val to: TestRecord, val maxStableKg: Double?) : DialogState()
    data class ConfirmClear(val scaleId: Int, val element: TestRecord, val count: Int) : DialogState()
    data class ConfirmDeleteElement(val scaleId: Int, val element: TestRecord) : DialogState()
    data class EditCapture(val scaleId: Int, val weighing: Weighing, val element: TestRecord) : DialogState()
    data class ReportReady(val title: String, val file: File, val mime: String) : DialogState()
}

data class DiagResult(val command: String, val raw: String, val table: List<Pair<String, String>>, val atMs: Long)

/** Estado visible de UNA balanza. */
data class ScaleUi(
    val id: Int,
    val settings: Settings,
    val link: LinkState = LinkState.Disconnected,
    val reading: Six1Reading? = null,
    val readingAtMs: Long = 0,
    /** Hora de la última lectura válida (con peso y estado S o D). */
    val lastValidAtMs: Long? = null,
    val lastRaw: String? = null,
    val sicsError: String? = null,
    val elements: List<TestRecord> = emptyList(),
    val element: TestRecord? = null,
    val weighings: List<Weighing> = emptyList(),
    val basket: Basket? = null,
    val cycle: CycleSnapshot = CycleSnapshot.EMPTY,
    val ledOn: Boolean = false,
    val diag: List<DiagResult> = emptyList(),
)

data class UiState(
    val scales: List<ScaleUi>,
    val baskets: List<Basket> = emptyList(),
    val screen: Screen = Screen.MAIN,
    val dialog: DialogState? = null,
    val message: String? = null,
    val filter: HistoryFilter = HistoryFilter(),
    val results: List<CaptureRecord> = emptyList(),
    val searched: Boolean = false,
    val allElements: List<TestRecord> = emptyList(),
    val diagScale: Int = 1,
) {
    fun scale(id: Int): ScaleUi = scales.first { it.id == id }
}

class PesosViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = AppSettings(app)
    private val db: PesosDb
    /** Todo lo que toca detectores + base de datos corre en un único hilo: sin carreras entre balanzas. */
    private val worker = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    /** Una balanza: su enlace (ACT350 o simulador), su sesión y su detector, independientes de la otra. */
    private inner class Scale(val id: Int, var settings: Settings) {
        var link: ScaleLink = newLink(settings)
        val session = WeighingSession(db, CycleDetector(settings.cycleConfig()), id)
        var jobs: List<Job> = emptyList()
        var ledJob: Job? = null
    }

    private val scales: List<Scale>
    private val _ui: MutableStateFlow<UiState>
    val ui: StateFlow<UiState>

    init {
        DbBackup.beforeOpen(app)
        db = PesosDb(app)
        scales = SCALE_IDS.map { Scale(it, prefs.load(it)) }
        _ui = MutableStateFlow(UiState(scales = scales.map { ScaleUi(it.id, it.settings) }))
        ui = _ui

        scales.forEach { attach(it) }
        viewModelScope.launch(worker) { restore() }
        scales.forEach { sc ->
            if (sc.settings.enabled && sc.settings.configured && sc.settings.autoConnect) connect(sc.id)
        }
    }

    private fun scale(id: Int) = scales.first { it.id == id }

    private fun updateScale(id: Int, f: (ScaleUi) -> ScaleUi) =
        _ui.update { s -> s.copy(scales = s.scales.map { if (it.id == id) f(it) else it }) }

    private fun newLink(s: Settings): ScaleLink =
        if (s.source == LinkSource.SIMULATOR) SimulatedScale(viewModelScope) else SicsClient(viewModelScope)

    private fun attach(sc: Scale) {
        sc.jobs.forEach { it.cancel() }
        sc.session.simulated = sc.settings.simulated
        val link = sc.link
        sc.jobs = listOf(
            viewModelScope.launch { link.link.collect { l -> updateScale(sc.id) { it.copy(link = l) } } },
            viewModelScope.launch(worker) { link.events.collect { handle(sc, it) } },
        )
    }

    private fun restore() {
        val baskets = db.baskets()
        val legacy = prefs.takeLegacySelectionFlag()
        for (sc in scales) {
            var sel = prefs.selectedElement(sc.id)
            if (sc.id == 1 && legacy && sel == null) sel = db.legacyOpenTest()?.id
            val el = sel?.let { db.getTest(it) }?.takeIf { it.scaleId == sc.id }
            if (el != null) {
                sc.session.start(el.id, el.mode)
                prefs.setSelectedElement(sc.id, el.id)
            }
            sc.session.basket = prefs.selectedBasket(sc.id)?.let { b -> baskets.firstOrNull { it.id == b } }
            publish(sc)
        }
        _ui.update { it.copy(baskets = baskets) }
    }

    /** Refresca elemento, lista de elementos y pesadas de una balanza (en el hilo worker). */
    private fun publish(sc: Scale) {
        val id = sc.session.testId
        val el = id?.let { db.getTest(it) }
        val list = id?.let { db.weighings(it) } ?: emptyList()
        val elements = db.elements(sc.id)
        updateScale(sc.id) {
            it.copy(
                element = el, weighings = list, elements = elements,
                cycle = sc.session.detector.snapshot(), basket = sc.session.basket,
            )
        }
    }

    // ---------------- Conexión ----------------

    fun connect(id: Int) {
        val sc = scale(id)
        val s = sc.settings
        when {
            !s.enabled -> say("${s.name} está desactivada en Ajustes")
            !s.configured -> say("Configure la IP de ${s.name} en Ajustes")
            else -> sc.link.start(s.host.trim(), s.port, s.pollMs)
        }
    }

    fun disconnect(id: Int) {
        val sc = scale(id)
        sc.link.stop()
        viewModelScope.launch(worker) {
            sc.session.onLinkLost(System.currentTimeMillis())
            updateScale(id) { it.copy(reading = null, cycle = sc.session.detector.snapshot()) }
        }
    }

    private fun handle(sc: Scale, e: ClientEvent) {
        when (e) {
            is ClientEvent.Response -> {
                val saved = sc.session.onResponse(e.timeMs, e.parsed)
                val r = (e.parsed as? SicsResponse.Six1)?.reading
                val valid = r != null && r.complete &&
                    (r.status == WeightStatus.STABLE || r.status == WeightStatus.DYNAMIC)
                updateScale(sc.id) {
                    it.copy(
                        reading = r,
                        readingAtMs = e.timeMs,
                        lastValidAtMs = if (valid) e.timeMs else it.lastValidAtMs,
                        lastRaw = e.raw,
                        sicsError = (e.parsed as? SicsResponse.Error)?.let { er -> "${er.code}: ${er.meaning}" }
                            ?: (e.parsed as? SicsResponse.Other)?.let { o -> "Respuesta inesperada: ${SicsParser.visible(o.raw)}" },
                        cycle = sc.session.detector.snapshot(),
                    )
                }
                if (saved.isNotEmpty()) {
                    publish(sc)
                    flashLed(sc)
                }
            }
            is ClientEvent.LinkLost -> {
                sc.session.onLinkLost(e.timeMs)
                updateScale(sc.id) { it.copy(reading = null, cycle = sc.session.detector.snapshot()) }
            }
        }
    }

    private fun flashLed(sc: Scale) {
        sc.ledJob?.cancel()
        sc.ledJob = viewModelScope.launch {
            updateScale(sc.id) { it.copy(ledOn = true) }
            delay(3_000)
            updateScale(sc.id) { it.copy(ledOn = false) }
        }
    }

    // ---------------- Elementos ----------------

    fun openElementForm(scaleId: Int, existing: TestRecord?) =
        _ui.update { it.copy(dialog = DialogState.ElementForm(scaleId, existing)) }

    /** Guarda el formulario de elemento. Devuelve un error para mostrar, o null si está bien. */
    fun saveElement(scaleId: Int, existing: TestRecord?, name: String, lote: String, pieces: Int?): String? {
        if (name.isBlank()) return "Escriba el nombre del elemento o modelo"
        if (pieces == null || pieces < 1) return "Las piezas por muestra deben ser 1 o más"
        dismissDialog()
        viewModelScope.launch(worker) {
            val sc = scale(scaleId)
            if (existing != null) {
                db.updateElement(existing.id, name.trim(), lote.trim(), pieces)
                publish(sc)
            } else {
                val t = db.createElement(
                    scaleId, name.trim(), lote.trim(), pieces, sc.settings.weightMode, System.currentTimeMillis(),
                )
                publish(sc)
                withContext(Dispatchers.Main) { selectElement(scaleId, t) }
            }
        }
        return null
    }

    fun selectElement(scaleId: Int, target: TestRecord) {
        val su = _ui.value.scale(scaleId)
        val current = su.element
        if (current?.id == target.id) return
        if (current != null && su.cycle.phase == CyclePhase.LOADED) {
            _ui.update { it.copy(dialog = DialogState.SwitchWithLoad(scaleId, current, target, su.cycle.maxStableKg)) }
        } else {
            doSelect(scaleId, target, PendingLoad.MOVE_TO_NEW)
        }
    }

    fun doSelect(scaleId: Int, target: TestRecord, pending: PendingLoad) {
        dismissDialog()
        viewModelScope.launch(worker) {
            val sc = scale(scaleId)
            if (pending == PendingLoad.SAVE_TO_PREVIOUS) {
                sc.session.closeCycle(System.currentTimeMillis(), save = true)?.let { flashLed(sc) }
            }
            sc.session.switchTo(target.id, target.mode)
            prefs.setSelectedElement(scaleId, target.id)
            publish(sc)
        }
    }

    fun requestDeleteElement(scaleId: Int, element: TestRecord) =
        _ui.update { it.copy(dialog = DialogState.ConfirmDeleteElement(scaleId, element)) }

    fun deleteElement(scaleId: Int, element: TestRecord) {
        dismissDialog()
        viewModelScope.launch(worker) {
            val sc = scale(scaleId)
            if (sc.session.testId == element.id) {
                sc.session.stop()
                prefs.setSelectedElement(scaleId, null)
            }
            db.deleteTest(element.id)
            publish(sc)
            say("Elemento ${element.name} eliminado")
        }
    }

    // ---------------- Canasta y captura ----------------

    fun selectBasket(scaleId: Int, basket: Basket?) {
        viewModelScope.launch(worker) {
            val sc = scale(scaleId)
            sc.session.basket = basket
            prefs.setSelectedBasket(scaleId, basket?.id)
            updateScale(scaleId) { it.copy(basket = basket) }
        }
    }

    /** Botón "Capturar ahora": guarda ya el máximo estable del ciclo; esa carga no se vuelve a registrar. */
    fun captureNow(scaleId: Int) {
        viewModelScope.launch(worker) {
            val sc = scale(scaleId)
            if (sc.session.testId == null) {
                say("Primero seleccione o cree un elemento en ${sc.settings.name}")
                return@launch
            }
            // Sin máximo estable no se toca el ciclo: seguirá esperando a que el ACT350 marque estable.
            if (sc.session.detector.snapshot().maxStableKg == null) {
                say("Aún no hay un peso estable para capturar en ${sc.settings.name}")
                return@launch
            }
            val w = sc.session.closeCycle(System.currentTimeMillis(), save = true)
            if (w != null) flashLed(sc)
            publish(sc)
        }
    }

    fun requestClear(scaleId: Int) {
        val su = _ui.value.scale(scaleId)
        val el = su.element ?: return
        if (su.weighings.isNotEmpty()) {
            _ui.update { it.copy(dialog = DialogState.ConfirmClear(scaleId, el, su.weighings.size)) }
        }
    }

    fun clearElement(scaleId: Int, element: TestRecord) {
        dismissDialog()
        viewModelScope.launch(worker) {
            db.clearWeighings(element.id)
            publish(scale(scaleId))
            say("Registros de ${element.name} borrados")
        }
    }

    fun editCapture(scaleId: Int, w: Weighing) {
        val el = _ui.value.scale(scaleId).element ?: return
        _ui.update { it.copy(dialog = DialogState.EditCapture(scaleId, w, el)) }
    }

    /** Desde el historial: abrir una pesada de cualquier balanza para corregir canasta o muestra. */
    fun editRecord(r: CaptureRecord) {
        val el = _ui.value.allElements.firstOrNull { it.id == r.w.testId } ?: return
        _ui.update { it.copy(dialog = DialogState.EditCapture(r.w.scaleId, r.w, el)) }
    }

    fun saveCapture(scaleId: Int, w: Weighing, basket: Basket?, sampleKg: Double?) {
        dismissDialog()
        viewModelScope.launch(worker) {
            db.updateCapture(w.id, basket?.name, basket?.tareKg ?: 0.0, sampleKg)
            publish(scale(scaleId))
            refreshResults()
        }
    }

    fun deleteCapture(scaleId: Int, w: Weighing) {
        dismissDialog()
        viewModelScope.launch(worker) {
            db.deleteCapture(w.id)
            publish(scale(scaleId))
            refreshResults()
            say("Pesada N° ${w.seq} eliminada")
        }
    }

    // ---------------- Historial y reportes ----------------

    fun openHistory() {
        go(Screen.HISTORY)
        viewModelScope.launch(worker) { _ui.update { it.copy(allElements = db.allElements()) } }
    }

    fun setFilter(f: HistoryFilter) = _ui.update { it.copy(filter = f) }

    fun search() = viewModelScope.launch(worker) {
        val results = db.query(_ui.value.filter)
        _ui.update { it.copy(results = results, searched = true, allElements = db.allElements()) }
    }

    private fun refreshResults() {
        if (_ui.value.searched) {
            val results = db.query(_ui.value.filter)
            _ui.update { it.copy(results = results) }
        }
    }

    private fun reportContext(): ReportContext {
        val s = _ui.value
        return ReportContext(
            filter = s.filter,
            scaleNames = s.scales.associate { it.id to it.settings.name },
            decimals = s.scales.associate { it.id to it.settings.decimals },
            elementLabel = s.filter.elementId?.let { id -> s.allElements.firstOrNull { it.id == id }?.label },
            generatedAt = System.currentTimeMillis(),
        )
    }

    fun export(excel: Boolean) = viewModelScope.launch(worker) {
        val records = _ui.value.results
        if (records.isEmpty()) {
            say("No hay registros para exportar. Pulse Buscar primero.")
            return@launch
        }
        val ctx = reportContext()
        val dir = File(getApplication<Application>().filesDir, "reportes").apply { mkdirs() }
        val stamp = Fmt.fileStamp(ctx.generatedAt)
        runCatching {
            if (excel) {
                val f = File(dir, "Pesajes_$stamp.xlsx")
                f.outputStream().use { XlsxReport.write(it, records, ctx) }
                f to XLSX_MIME
            } else {
                val f = File(dir, "Pesajes_$stamp.pdf")
                PdfReport.write(f, records, ctx)
                f to "application/pdf"
            }
        }.onSuccess { (file, mime) ->
            _ui.update { it.copy(dialog = DialogState.ReportReady("Reporte de ${records.size} registros", file, mime)) }
        }.onFailure { say("No se pudo generar el reporte: ${it.message}") }
    }

    fun saveReportTo(uri: Uri, file: File) = viewModelScope.launch(worker) {
        val ok = runCatching {
            getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: error("sin destino")
        }.isSuccess
        say(if (ok) "Archivo guardado" else "No se pudo guardar el archivo")
    }

    // ---------------- Ajustes ----------------

    /** Guarda los ajustes de una balanza. Devuelve el error a mostrar, o null si está bien. */
    fun saveScaleSettings(new: Settings): String? {
        new.validate()?.let { return it }
        val other = scales.first { it.id != new.scaleId }.settings
        if (new.enabled && other.enabled &&
            new.source == LinkSource.ACT350 && other.source == LinkSource.ACT350 &&
            new.host.trim() == other.host.trim()
        ) {
            return "La IP ${new.host.trim()} ya la usa ${other.name}. Cada balanza necesita su propia IP."
        }
        val sc = scale(new.scaleId)
        val old = sc.settings
        prefs.save(new)
        sc.settings = new
        updateScale(new.scaleId) { it.copy(settings = new) }
        viewModelScope.launch(worker) { sc.session.detector.config = new.cycleConfig() }

        val linkChanged = old.source != new.source || old.host.trim() != new.host.trim() ||
            old.port != new.port || old.pollMs != new.pollMs || old.enabled != new.enabled
        if (linkChanged) {
            val wasRunning = sc.link.isRunning
            sc.link.stop()
            if (old.source != new.source) {
                sc.link = newLink(new)
                attach(sc)
            }
            viewModelScope.launch(worker) {
                sc.session.onLinkLost(System.currentTimeMillis())
                updateScale(new.scaleId) { it.copy(reading = null, lastValidAtMs = null) }
            }
            if (new.enabled && new.configured && (wasRunning || new.autoConnect)) connect(new.scaleId)
        }
        say("Ajustes de ${new.name} guardados")
        return null
    }

    fun addBasket(name: String, tare: Double?): String? {
        if (name.isBlank()) return "Escriba el nombre de la canasta"
        if (tare == null || tare < 0) return "Escriba una tara válida en kg"
        viewModelScope.launch(worker) {
            db.addBasket(name.trim(), tare)
            _ui.update { it.copy(baskets = db.baskets()) }
        }
        return null
    }

    fun deleteBasket(b: Basket) = viewModelScope.launch(worker) {
        db.deleteBasket(b.id)
        for (sc in scales) {
            if (sc.session.basket?.id == b.id) {
                sc.session.basket = null
                prefs.setSelectedBasket(sc.id, null)
                updateScale(sc.id) { it.copy(basket = null) }
            }
        }
        _ui.update { it.copy(baskets = db.baskets()) }
    }

    // ---------------- Prueba de conexión ----------------

    fun setDiagScale(id: Int) = _ui.update { it.copy(diagScale = id) }

    fun sendDiag(scaleId: Int, command: String) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        val result = runCatching { scale(scaleId).link.transact(command) }
        val d = result.fold(
            onSuccess = { raw ->
                val table = if (command == "SIX1") SicsParser.describeSix1(raw) else emptyList()
                val interp = when (val p = SicsParser.parse(raw)) {
                    is SicsResponse.Six1 -> p.reading.let { r ->
                        listOf(
                            "→ Estado" to r.status.label,
                            "→ Bruto" to "${r.gross ?: "-"} ${r.unit ?: ""}",
                            "→ Neto" to "${r.net ?: "-"} ${r.unit ?: ""}",
                            "→ Tara" to "${r.tare ?: "-"} ${r.unit ?: ""}",
                            "→ Decimales recibidos" to (r.decimals?.toString() ?: "-"),
                        )
                    }
                    is SicsResponse.Error -> listOf("→ Error" to p.meaning)
                    is SicsResponse.Other -> emptyList()
                }
                DiagResult(command, raw, table + interp, now)
            },
            onFailure = { DiagResult(command, "", listOf("Error" to (it.message ?: "sin conexión")), now) },
        )
        updateScale(scaleId) { it.copy(diag = (listOf(d) + it.diag).take(10)) }
    }

    fun diagText(scaleId: Int): String {
        val s = _ui.value.scale(scaleId)
        return buildString {
            appendLine("Dacar - prueba de conexión ${s.settings.name} (${s.settings.model}) ${s.settings.host}:${s.settings.port}")
            if (s.settings.simulated) appendLine("ATENCIÓN: balanza en modo SIMULADOR")
            s.diag.forEach { d ->
                appendLine("[${Fmt.dateTime(d.atMs)}] Enviado: ${d.command}\\r\\n")
                appendLine("Recibido: ${SicsParser.visible(d.raw)}")
                d.table.forEach { (k, v) -> appendLine("  $k = $v") }
            }
        }
    }

    // ---------------- Navegación ----------------

    fun go(screen: Screen) = _ui.update { it.copy(screen = screen) }
    fun dismissDialog() = _ui.update { it.copy(dialog = null) }
    fun consumeMessage() = _ui.update { it.copy(message = null) }
    private fun say(text: String) = _ui.update { it.copy(message = text) }

    override fun onCleared() {
        scales.forEach { it.link.stop() }
        worker.close()
        db.close()
    }

    companion object {
        val SCALE_IDS = listOf(1, 2)
        const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }
}
