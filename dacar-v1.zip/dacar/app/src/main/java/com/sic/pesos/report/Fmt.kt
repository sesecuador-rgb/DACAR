package com.sic.pesos.report

import com.sic.pesos.data.Weighing
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

object Fmt {
    private val locale = Locale("es", "EC")
    private fun f(p: String) = SimpleDateFormat(p, locale)
    private val dayFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    fun date(ms: Long): String = f("dd/MM/yyyy").format(Date(ms))
    fun time(ms: Long): String = f("HH:mm:ss").format(Date(ms))
    fun dateTime(ms: Long): String = f("dd/MM/yyyy HH:mm:ss").format(Date(ms))
    fun fileStamp(ms: Long): String = f("yyyyMMdd_HHmmss").format(Date(ms))
    fun day(d: LocalDate): String = d.format(dayFmt)

    fun round(v: Double, decimals: Int): BigDecimal =
        BigDecimal(v).setScale(decimals, RoundingMode.HALF_UP)

    fun kg(v: Double, decimals: Int): String = round(v, decimals).toPlainString()

    /** Suma exacta de los valores tal como se muestran (sin error de coma flotante). */
    fun total(list: List<Weighing>, decimals: Int): String =
        list.fold(BigDecimal.ZERO) { acc, w -> acc + round(w.kg, decimals) }
            .setScale(decimals, RoundingMode.HALF_UP).toPlainString()

    fun totalNet(list: List<Weighing>, decimals: Int): String =
        list.fold(BigDecimal.ZERO) { acc, w -> acc + round(w.kg, decimals) - round(w.tareKg, decimals) }
            .setScale(decimals, RoundingMode.HALF_UP).toPlainString()

    /** Entero con separador de miles: 11039 → "11.039". */
    fun units(n: Long): String = String.format(locale, "%,d", n)
}
