package com.sic.pesos.report

import com.sic.pesos.data.CaptureRecord
import com.sic.pesos.data.HistoryFilter
import java.math.BigDecimal

/** Datos comunes al PDF y al Excel. Lógica pura: se prueba con JUnit. */
class ReportContext(
    val filter: HistoryFilter,
    val scaleNames: Map<Int, String>,
    val decimals: Map<Int, Int>,
    val elementLabel: String?,
    val generatedAt: Long,
) {
    fun scaleName(id: Int) = scaleNames[id] ?: "Balanza $id"
    fun decimalsOf(id: Int) = decimals[id] ?: 2
}

data class Summary(
    val count: Int,
    /** Totales de peso por unidad: nunca se suman unidades distintas entre sí. */
    val grossByUnit: Map<String, BigDecimal>,
    val netByUnit: Map<String, BigDecimal>,
    /**
     * Total de unidades (piezas): solo si todos los registros son del MISMO elemento y todos
     * tienen peso de muestra; sumar piezas de modelos distintos no tiene sentido.
     */
    val totalUnits: Long?,
)

object ReportData {

    fun filterLines(ctx: ReportContext): List<Pair<String, String>> = listOf(
        "Balanza" to (ctx.filter.scaleId?.let { ctx.scaleName(it) } ?: "Ambas"),
        "Desde" to (ctx.filter.fromDay?.let { Fmt.day(it) } ?: "Sin límite"),
        "Hasta" to (ctx.filter.toDay?.let { Fmt.day(it) } ?: "Sin límite"),
        "Elemento" to (ctx.elementLabel ?: "Todos"),
    )

    fun summarize(records: List<CaptureRecord>, decimalsOf: (Int) -> Int): Summary {
        val gross = LinkedHashMap<String, BigDecimal>()
        val net = LinkedHashMap<String, BigDecimal>()
        for (r in records) {
            val d = decimalsOf(r.w.scaleId)
            val g = Fmt.round(r.w.kg, d)
            val n = g - Fmt.round(r.w.tareKg, d)
            gross[r.w.unit] = (gross[r.w.unit] ?: BigDecimal.ZERO) + g
            net[r.w.unit] = (net[r.w.unit] ?: BigDecimal.ZERO) + n
        }
        val sameElement = records.isNotEmpty() && records.map { it.w.testId }.distinct().size == 1
        val units = records.map { it.units }
        val totalUnits = if (sameElement && units.all { it != null }) units.sumOf { it!! } else null
        return Summary(records.size, gross, net, totalUnits)
    }

    /** Subtotales por balanza, cuando el reporte incluye las dos. */
    fun perScale(records: List<CaptureRecord>, decimalsOf: (Int) -> Int): Map<Int, Summary> =
        records.groupBy { it.w.scaleId }.toSortedMap().mapValues { (_, list) -> summarize(list, decimalsOf) }

    fun includesSeveralScales(records: List<CaptureRecord>) = records.map { it.w.scaleId }.distinct().size > 1
}
