package com.sic.pesos.sics

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.Locale
import kotlin.random.Random

/**
 * SIMULADOR de pruebas (NO es el equipo real). Genera respuestas SIX1 con el mismo formato que
 * devolvió el ACT350 real, para probar la pantalla y la captura sin el segundo controlador.
 * Las pesadas que produce se guardan con estado "SIMULADO".
 */
class SimulatedScale(
    private val scope: CoroutineScope,
    private val seed: Long = System.nanoTime(),
) : ScaleLink {
    private val _link = MutableStateFlow<LinkState>(LinkState.Disconnected)
    override val link: StateFlow<LinkState> = _link
    private val _events = MutableSharedFlow<ClientEvent>(extraBufferCapacity = 64)
    override val events: SharedFlow<ClientEvent> = _events
    private var job: Job? = null
    @Volatile private var current = SimProfile.line("S", 0.0)

    override val isRunning: Boolean get() = job?.isActive == true

    override fun start(host: String, port: Int, pollMs: Long) {
        stop()
        job = scope.launch(Dispatchers.Default) {
            _link.value = LinkState.Connected("SIMULADO")
            val profile = SimProfile(Random(seed))
            while (isActive) {
                val t = System.currentTimeMillis()
                val line = profile.lineAt(t)
                current = line
                _events.emit(ClientEvent.Response(t, line, SicsParser.parse(line)))
                delay(pollMs)
            }
        }
    }

    override fun stop() {
        job?.cancel()
        job = null
        _link.value = LinkState.Disconnected
    }

    override suspend fun transact(command: String): String {
        ScaleLink.checkReadOnly(command)
        if (!isRunning) throw IOException("Simulador detenido")
        return when (command) {
            "I3" -> "I3 A \"SIMULADO\"\r\n"
            "I4" -> "I4 A \"SIMULADO\"\r\n"
            else -> current
        }
    }
}

/** Ciclo simulado: 3 s en cero, 1,2 s subiendo, 3 s estable, 0,8 s bajando. */
internal class SimProfile(private val rnd: Random) {
    private val durations = longArrayOf(3_000, 1_200, 3_000, 800)
    private var phase = 0
    private var phaseStart = 0L
    private var target = 0.0

    fun lineAt(t: Long): String {
        if (phaseStart == 0L) phaseStart = t
        var guard = 0
        while (t - phaseStart >= durations[phase] && guard++ < 1_000) {
            phaseStart += durations[phase]
            phase = (phase + 1) % durations.size
            if (phase == 1) target = 100 + rnd.nextInt(900) + rnd.nextInt(10) / 10.0
        }
        if (guard >= 1_000) phaseStart = t
        val f = ((t - phaseStart).toDouble() / durations[phase]).coerceIn(0.0, 1.0)
        return when (phase) {
            0 -> line("S", 0.0)
            1 -> line("D", target * f + rnd.nextInt(-20, 20) / 10.0)
            2 -> line("S", target)
            else -> line("D", target * (1 - f))
        }
    }

    companion object {
        fun line(sts: String, kg: Double): String {
            val w = if (kg < 0.05) 0.0 else kg
            val coz = if (w == 0.0) "Z" else "N"
            return String.format(Locale.US, "SIX1 %s 0 %s N R 0 0 0 1 N %10.1f %10.1f %10.1f kg\r\n", sts, coz, w, w, 0.0)
        }
    }
}
