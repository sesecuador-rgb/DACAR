package com.sic.pesos.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sic.pesos.cycle.CyclePhase
import com.sic.pesos.data.Basket
import com.sic.pesos.data.WeightMode
import com.sic.pesos.report.Fmt
import com.sic.pesos.sics.LinkState
import com.sic.pesos.sics.WeightStatus
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: PesosViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La tablet no se apaga mientras la app está abierta: el registro no se interrumpe.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { PesosTheme { PesosApp(vm) } }
    }
}

/** Una lectura con más de este tiempo ya no se muestra como peso actual. */
const val STALE_MS = 2_500L

@Composable
fun PesosApp(vm: PesosViewModel) {
    val s by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    LaunchedEffect(s.message) {
        s.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show()
            vm.consumeMessage()
        }
    }
    BackHandler(enabled = s.screen != Screen.MAIN) { vm.go(Screen.MAIN) }

    Surface(Modifier.fillMaxSize(), color = Pal.Bg) {
        Column(Modifier.fillMaxSize().background(Pal.Blue).safeDrawingPadding().background(Pal.Bg)) {
            TopBar(s, vm)
            Box(Modifier.weight(1f)) {
                when (s.screen) {
                    Screen.MAIN -> WeighScreen(s, vm)
                    Screen.HISTORY -> HistoryScreen(s, vm)
                    Screen.SETTINGS -> SettingsScreen(s, vm)
                    Screen.DIAGNOSTICS -> DiagnosticsScreen(s, vm)
                }
            }
        }
        Dialogs(s, vm)
    }
}

@Composable
private fun TopBar(s: UiState, vm: PesosViewModel) {
    Row(
        Modifier.fillMaxWidth().background(Pal.Blue).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Dacar", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        NavButton("Pesaje", s.screen == Screen.MAIN) { vm.go(Screen.MAIN) }
        NavButton("Historial", s.screen == Screen.HISTORY) { vm.openHistory() }
        NavButton("Prueba de conexión", s.screen == Screen.DIAGNOSTICS) { vm.go(Screen.DIAGNOSTICS) }
        NavButton("Ajustes", s.screen == Screen.SETTINGS) { vm.go(Screen.SETTINGS) }
    }
}

@Composable
private fun NavButton(text: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(
            text,
            color = if (selected) Color.White else Color(0xFFB9CDE0),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 17.sp,
        )
    }
}

@Composable
fun LinkPill(link: LinkState) {
    when (link) {
        is LinkState.Connected -> Pill("Conectado", Pal.Green)
        is LinkState.Connecting -> Pill("Conectando…", Pal.Amber)
        is LinkState.Retrying -> Pill("Sin conexión", Pal.Red)
        LinkState.Disconnected -> Pill("Sin conexión", Pal.Red)
    }
}

// ============================ Pantalla de pesaje: dos balanzas ============================

@Composable
private fun WeighScreen(s: UiState, vm: PesosViewModel) {
    // Reloj de 1 s: sirve para detectar lecturas viejas aunque no lleguen datos nuevos.
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            delay(1_000)
            value = System.currentTimeMillis()
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(10.dp)) {
        if (maxWidth > maxHeight) {
            // Tablet horizontal: Balanza 1 a la izquierda, Balanza 2 a la derecha.
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                s.scales.forEach { su -> ScalePanel(su, s.baskets, vm, now, Modifier.weight(1f).fillMaxSize()) }
            }
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                s.scales.forEach { su -> ScalePanel(su, s.baskets, vm, now, Modifier.weight(1f).fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun ScalePanel(su: ScaleUi, baskets: List<Basket>, vm: PesosViewModel, now: Long, modifier: Modifier) {
    val st = su.settings
    val connected = su.link is LinkState.Connected
    val fresh = connected && su.reading != null && now - su.readingAtMs < STALE_MS
    val dec = su.reading?.decimals ?: st.decimals

    Panel(modifier, padding = 12.dp) {
        // Encabezado: nombre, modelo/IP y estado de comunicación
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(st.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Pal.Ink, maxLines = 1)
                Text(
                    if (st.simulated) "${st.model}, simulador" else "${st.model}, ${st.host.ifBlank { "IP sin configurar" }}:${st.port}",
                    fontSize = 13.sp, color = Pal.Muted, maxLines = 1,
                )
            }
            if (st.simulated) {
                Pill("SIMULADO", Pal.Amber)
                Spacer(Modifier.width(6.dp))
            }
            if (st.enabled) LinkPill(su.link) else Pill("Desactivada", Pal.LedOff)
        }
        Spacer(Modifier.height(8.dp))

        Readout(su, fresh, now, dec, vm)
        Spacer(Modifier.height(8.dp))

        // Elemento y canasta (propios de esta balanza)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Picker(
                label = "Elemento / prueba",
                current = su.element?.label ?: "Seleccione…",
                options = su.elements,
                text = { "${it.label}   (${it.count} pesadas)" },
                onPick = { vm.selectElement(su.id, it) },
                modifier = Modifier.weight(1.5f),
                actions = buildList<Pair<String, () -> Unit>> {
                    add("+ Nuevo elemento" to { vm.openElementForm(su.id, null) })
                    su.element?.let { el -> add("Editar ${el.name}" to { vm.openElementForm(su.id, el) }) }
                },
            )
            Picker(
                label = "Canasta (tara)",
                current = su.basket?.name ?: "Sin canasta",
                options = listOf<Basket?>(null) + baskets,
                text = { it?.let { b -> "${b.name}  (${Fmt.kg(b.tareKg, 1)} kg)" } ?: "Sin canasta (tara 0)" },
                onPick = { vm.selectBasket(su.id, it) },
                modifier = Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(8.dp))

        // Ciclo actual y captura
        CycleRow(su, dec, vm)

        // Totales del elemento
        Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Stat("Pesadas", su.weighings.size.toString())
            Spacer(Modifier.width(24.dp))
            Stat("Suma neto", "${Fmt.totalNet(su.weighings, st.decimals)} kg")
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.requestClear(su.id) }, enabled = su.weighings.isNotEmpty()) {
                Text("Borrar registros", color = if (su.weighings.isNotEmpty()) Pal.Red else Pal.Muted, fontSize = 15.sp)
            }
        }

        val cols = listOf(
            Col("N°", 0.5f, true), Col("Hora", 1.1f), Col("Bruto", 1f, true),
            Col("Tara", 0.8f, true), Col("Neto", 1f, true), Col("Unid.", 0.9f, true),
        )
        DataHeader(cols)
        val newest = su.weighings.maxOfOrNull { it.seq }
        LazyColumn(Modifier.weight(1f)) {
            items(su.weighings.sortedByDescending { it.seq }, key = { it.id }) { w ->
                val units = su.element?.let { com.sic.pesos.data.Units.of(w.netKg, it.samplePieces, w.sampleKg) }
                DataRow(
                    listOf(
                        Col(w.seq.toString(), 0.5f, true),
                        Col(Fmt.time(w.atMs), 1.1f),
                        Col(Fmt.kg(w.kg, st.decimals), 1f, true),
                        Col(Fmt.kg(w.tareKg, st.decimals), 0.8f, true),
                        Col(Fmt.kg(w.netKg, st.decimals), 1f, true),
                        Col(units?.let { Fmt.units(it) } ?: "—", 0.9f, true),
                    ),
                    highlight = su.ledOn && w.seq == newest,
                    onClick = { vm.editCapture(su.id, w) },
                )
            }
        }
        if (su.element != null && su.weighings.isNotEmpty()) {
            Text(
                "Toque una pesada para elegir su canasta o escribir el peso de la muestra.",
                fontSize = 12.sp, color = Pal.Muted,
            )
        }
    }
}

@Composable
private fun Readout(su: ScaleUi, fresh: Boolean, now: Long, dec: Int, vm: PesosViewModel) {
    val st = su.settings
    val r = su.reading
    fun num(v: Double?) = v?.let { String.format(Locale.US, "%.${dec}f", it) } ?: "----"
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Pal.Readout).padding(12.dp)
    ) {
        when {
            !st.enabled -> ReadoutMessage("Balanza desactivada", "Actívela en Ajustes.")
            !st.configured -> ReadoutMessage("Sin configurar", "Escriba la IP del controlador en Ajustes.")
            !fresh -> {
                val last = su.lastValidAtMs?.let {
                    val day = if (Fmt.date(it) == Fmt.date(now)) "" else "${Fmt.date(it)} "
                    "Última lectura válida: $day${Fmt.time(it)}"
                } ?: "Aún no hay lecturas válidas"
                val reason = (su.link as? LinkState.Retrying)?.reason
                ReadoutMessage(
                    "Sin conexión",
                    listOfNotNull(last, reason).joinToString("\n"),
                )
                if (su.link == LinkState.Disconnected) {
                    Button(onClick = { vm.connect(su.id) }, modifier = Modifier.padding(top = 6.dp)) { Text("Conectar") }
                }
            }
            else -> {
                val mode = su.element?.mode ?: st.weightMode
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(mode.label, color = Color(0xFFB9CDE0), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    val (txt, col) = when {
                        r == null -> "Sin datos" to Pal.LedOff
                        r.status == WeightStatus.STABLE && r.complete -> "Estable" to Pal.Green
                        r.status == WeightStatus.DYNAMIC && r.complete -> "Inestable" to Pal.Amber
                        else -> r.status.label to Pal.Red
                    }
                    Pill(txt, col)
                }
                val shown = r?.let { if (mode == WeightMode.GROSS) it.gross else it.net }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(num(shown), color = Color.White, fontFamily = Digits, fontWeight = FontWeight.Bold, fontSize = 64.sp)
                    Spacer(Modifier.width(10.dp))
                    Text(r?.unit ?: "", color = Color.White, fontSize = 26.sp, modifier = Modifier.padding(bottom = 12.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    listOf("Bruto" to r?.gross, "Neto" to r?.net, "Tara ACT350" to r?.tare).forEach { (k, v) ->
                        Column {
                            Text(k, color = Color(0xFF8FA8C0), fontSize = 12.sp)
                            Text(num(v), color = Color.White, fontFamily = Digits, fontSize = 18.sp)
                        }
                    }
                }
                su.sicsError?.let { Text(it, color = Color(0xFFFFB4A8), fontSize = 13.sp) }
            }
        }
    }
}

@Composable
private fun ReadoutMessage(title: String, detail: String) {
    Text(title, color = Color(0xFFFFB4A8), fontSize = 40.sp, fontWeight = FontWeight.Bold)
    if (detail.isNotBlank()) Text(detail, color = Color.White, fontSize = 15.sp)
    Text(
        "El ACT350 admite una sola conexión: cierre su página web en el navegador.",
        color = Color(0xFF8FA8C0), fontSize = 12.sp,
    )
}

@Composable
private fun CycleRow(su: ScaleUi, dec: Int, vm: PesosViewModel) {
    val c = su.cycle
    val next = (su.weighings.maxOfOrNull { it.seq } ?: 0) + 1
    val hint = when {
        su.element == null -> "Seleccione o cree un elemento para registrar pesadas."
        c.awaitingUnload -> "Pesada capturada. Retire la carga antes de la siguiente."
        c.phase == CyclePhase.WAITING_LOAD -> "Coloque la carga en la balanza."
        c.maxStableKg == null -> "Esperando peso estable…"
        c.unloading -> "Descarga detectada, guardando…"
        else -> "Retire la carga para registrar la pesada $next, o pulse Capturar ahora."
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Máximo estable del ciclo (provisional)", color = Pal.Muted, fontSize = 13.sp)
            Text(
                c.maxStableKg?.let { "${Fmt.kg(it, dec)} kg" } ?: "—",
                fontFamily = Digits, fontWeight = FontWeight.Bold, fontSize = 28.sp, color = Pal.Ink,
            )
            Text(hint, color = Pal.Ink, fontSize = 14.sp)
            c.warning?.let { Text(it.text, color = Pal.Amber, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CaptureLed(su.ledOn, 44.dp)
            OutlinedButton(
                onClick = { vm.captureNow(su.id) },
                enabled = su.element != null && c.maxStableKg != null,
                modifier = Modifier.padding(top = 4.dp),
            ) { Text("Capturar ahora", fontSize = 15.sp) }
        }
    }
}

// ============================ Utilidades para compartir archivos ============================

private fun uriFor(ctx: Context, file: File) =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)

fun shareFile(ctx: Context, file: File, mime: String) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uriFor(ctx, file))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Compartir reporte"))
}

fun openFile(ctx: Context, file: File, mime: String) {
    val i = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uriFor(ctx, file), mime)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        ctx.startActivity(i)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(ctx, "No hay una app para abrir este archivo; use Compartir", Toast.LENGTH_LONG).show()
    }
}
