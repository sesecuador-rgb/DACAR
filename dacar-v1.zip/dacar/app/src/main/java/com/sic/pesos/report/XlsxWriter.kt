package com.sic.pesos.report

import java.io.OutputStream
import java.time.Instant
import java.time.ZoneId
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Escribe un .xlsx (Office Open XML) mínimo y válido, sin librerías externas.
 * Las fechas se guardan como fecha real de Excel (número de serie con formato), y los pesos como
 * números, para que se puedan ordenar, filtrar y sumar en Excel. Sin Android: se prueba con JUnit.
 */
object XlsxWriter {

    /** Índices de estilo definidos en styles.xml. */
    object Style {
        const val NORMAL = 0
        const val BOLD = 1
        const val TITLE = 2
        const val DATE = 3        // dd/mm/yyyy
        const val TIME = 4        // hh:mm:ss
        const val DEC0 = 5        // 0
        const val DEC1 = 6        // 0.0
        const val DEC2 = 7        // 0.00
        const val DEC3 = 8        // 0.000
        const val HEADER = 9      // negrita, fondo gris, borde
        const val THOUSANDS = 10  // #,##0
        const val DATETIME = 11   // dd/mm/yyyy hh:mm:ss

        fun decimals(d: Int) = DEC0 + d.coerceIn(0, 3)
    }

    sealed class Cell {
        data class Text(val text: String, val style: Int = Style.NORMAL) : Cell()
        data class Num(val value: Double, val style: Int = Style.NORMAL) : Cell()
        /** Fecha/hora real de Excel a partir de milisegundos. */
        data class DateTime(val epochMs: Long, val style: Int = Style.DATETIME) : Cell()
        data object Blank : Cell()
    }

    class Sheet(
        val name: String,
        val rows: List<List<Cell>>,
        val columnWidths: List<Double>,
        /** Fila (1-based) de encabezados de la tabla: se congela para que quede visible al desplazar. */
        val freezeBelowRow: Int? = null,
    )

    fun write(out: OutputStream, sheet: Sheet, zone: ZoneId = ZoneId.systemDefault()) {
        val zip = ZipOutputStream(out)
        fun put(path: String, content: String) {
            zip.putNextEntry(ZipEntry(path))
            zip.write(content.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        put("[Content_Types].xml", CONTENT_TYPES)
        put("_rels/.rels", ROOT_RELS)
        put("xl/workbook.xml", workbook(sheet.name))
        put("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
        put("xl/styles.xml", STYLES)
        put("xl/worksheets/sheet1.xml", sheetXml(sheet, zone))
        zip.finish()
    }

    /** Número de serie de Excel (días desde 1899-12-30) en la hora local. */
    fun excelSerial(epochMs: Long, zone: ZoneId): Double {
        val offsetMs = zone.rules.getOffset(Instant.ofEpochMilli(epochMs)).totalSeconds * 1000L
        return (epochMs + offsetMs) / 86_400_000.0 + 25_569.0
    }

    fun columnName(index0: Int): String {
        var n = index0 + 1
        val sb = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            sb.append('A' + r)
            n = (n - 1) / 26
        }
        return sb.reverse().toString()
    }

    fun escape(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch == '\t' || ch == '\n' || ch == '\r' -> sb.append(ch)
                ch < ' ' -> Unit // caracteres de control no válidos en XML
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun sheetXml(sheet: Sheet, zone: ZoneId): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="$NS_MAIN" xmlns:r="$NS_REL">""")
        sheet.freezeBelowRow?.let { r ->
            sb.append("""<sheetViews><sheetView workbookViewId="0">""")
            sb.append("""<pane ySplit="$r" topLeftCell="A${r + 1}" activePane="bottomLeft" state="frozen"/>""")
            sb.append("""</sheetView></sheetViews>""")
        }
        sb.append("""<sheetFormatPr defaultRowHeight="15"/>""")
        if (sheet.columnWidths.isNotEmpty()) {
            sb.append("<cols>")
            sheet.columnWidths.forEachIndexed { i, w ->
                sb.append("""<col min="${i + 1}" max="${i + 1}" width="$w" customWidth="1"/>""")
            }
            sb.append("</cols>")
        }
        sb.append("<sheetData>")
        sheet.rows.forEachIndexed { ri, row ->
            val r = ri + 1
            sb.append("""<row r="$r">""")
            row.forEachIndexed { ci, cell ->
                val ref = columnName(ci) + r
                when (cell) {
                    is Cell.Text -> sb.append(
                        """<c r="$ref" t="inlineStr" s="${cell.style}"><is><t xml:space="preserve">${escape(cell.text)}</t></is></c>"""
                    )
                    is Cell.Num -> if (cell.value.isFinite()) {
                        sb.append("""<c r="$ref" s="${cell.style}"><v>${cell.value}</v></c>""")
                    }
                    is Cell.DateTime -> sb.append(
                        """<c r="$ref" s="${cell.style}"><v>${excelSerial(cell.epochMs, zone)}</v></c>"""
                    )
                    Cell.Blank -> Unit
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData>")
        sb.append("""<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>""")
        sb.append("""<pageSetup orientation="landscape"/>""")
        sb.append("</worksheet>")
        return sb.toString()
    }

    private const val NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    private fun workbook(name: String) =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<workbook xmlns="$NS_MAIN" xmlns:r="$NS_REL">""" +
            """<sheets><sheet name="${escape(name.take(31))}" sheetId="1" r:id="rId1"/></sheets></workbook>"""

    private const val CONTENT_TYPES =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""" +
            """<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""" +
            """<Default Extension="xml" ContentType="application/xml"/>""" +
            """<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""" +
            """<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""" +
            """<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""" +
            """</Types>"""

    private const val ROOT_RELS =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>""" +
            """</Relationships>"""

    private const val WORKBOOK_RELS =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>""" +
            """<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""" +
            """</Relationships>"""

    private const val STYLES =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<styleSheet xmlns="$NS_MAIN">""" +
            """<numFmts count="6">""" +
            """<numFmt numFmtId="164" formatCode="dd/mm/yyyy"/>""" +
            """<numFmt numFmtId="165" formatCode="hh:mm:ss"/>""" +
            """<numFmt numFmtId="166" formatCode="0.0"/>""" +
            """<numFmt numFmtId="167" formatCode="0.00"/>""" +
            """<numFmt numFmtId="168" formatCode="0.000"/>""" +
            """<numFmt numFmtId="169" formatCode="dd/mm/yyyy hh:mm:ss"/>""" +
            """</numFmts>""" +
            """<fonts count="3">""" +
            """<font><sz val="11"/><name val="Calibri"/><family val="2"/></font>""" +
            """<font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font>""" +
            """<font><b/><sz val="14"/><name val="Calibri"/><family val="2"/></font>""" +
            """</fonts>""" +
            """<fills count="3">""" +
            """<fill><patternFill patternType="none"/></fill>""" +
            """<fill><patternFill patternType="gray125"/></fill>""" +
            """<fill><patternFill patternType="solid"><fgColor rgb="FFDCE6F0"/><bgColor indexed="64"/></patternFill></fill>""" +
            """</fills>""" +
            """<borders count="2">""" +
            """<border><left/><right/><top/><bottom/><diagonal/></border>""" +
            """<border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right>""" +
            """<top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border>""" +
            """</borders>""" +
            """<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>""" +
            """<cellXfs count="12">""" +
            """<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>""" +
            """<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>""" +
            """<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>""" +
            """<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """<xf numFmtId="1" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """<xf numFmtId="167" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """<xf numFmtId="168" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>""" +
            """<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """<xf numFmtId="169" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>""" +
            """</cellXfs>""" +
            """<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>""" +
            """</styleSheet>"""
}
