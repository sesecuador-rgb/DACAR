package com.sic.pesos

import com.sic.pesos.cycle.CycleConfig
import com.sic.pesos.cycle.CycleDetector
import com.sic.pesos.cycle.WeighingSession
import com.sic.pesos.data.WeightMode
import com.sic.pesos.sics.SicsParser
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import java.util.Locale

/**
 * Dos balanzas a la vez, cada una con su sesión y su detector, guardando en el MISMO almacén
 * (como en la app). Balanza 1 → elemento 1 "Prueba 1"; balanza 2 → elemento 2 "Prueba 2".
 */
class TwoScalesTest {
    private lateinit var store: FakeStore
    private lateinit var b1: WeighingSession
    private lateinit var b2: WeighingSession
    private var clock = 0L
    private var ids = 0

    @Before
    fun setUp() {
        store = FakeStore()
        val newId = { "ciclo-${++ids}" }
        b1 = WeighingSession(store, CycleDetector(CycleConfig.suggested(0.1), newId), scaleId = 1)
        b2 = WeighingSession(store, CycleDetector(CycleConfig.suggested(0.1), newId), scaleId = 2)
        b1.start(1, WeightMode.GROSS)
        b2.start(2, WeightMode.GROSS)
    }

    private fun line(sts: String, kg: Double) =
        String.format(Locale.US, "SIX1 %s 0 N N R 0 0 0 1 N %10.1f %10.1f %10.1f kg\r\n", sts, kg, kg, 0.0)

    /** Un instante de sondeo: llegan las dos lecturas (null = esa balanza no respondió). */
    private fun tick(s1: Pair<String, Double>?, s2: Pair<String, Double>?) {
        clock += 100
        s1?.let { b1.onResponse(clock, SicsParser.parse(line(it.first, it.second))) }
        s2?.let { b2.onResponse(clock, SicsParser.parse(line(it.first, it.second))) }
    }

    @Test
    fun dos_pesos_simultaneos_no_cruzan_registros() {
        repeat(3) { tick("S" to 0.0, "S" to 0.0) }
        tick("D" to 150.0, "D" to 40.0)
        tick("S" to 184.0, "D" to 80.0)
        tick("S" to 184.0, "S" to 96.5)
        tick("D" to 20.0, "S" to 96.5)
        tick("S" to 0.0, "D" to 10.0)          // balanza 1 descarga
        tick("D" to 90.0, "S" to 0.0)          // balanza 2 descarga; B1 ya carga otra
        tick("S" to 99.0, "S" to 0.0)
        tick("S" to 0.0, "S" to 0.0)

        val porBalanza = store.rows.groupBy { it.scaleId }
        assertEquals(listOf(184.0, 99.0), porBalanza[1]!!.map { it.kg })
        assertEquals(listOf(96.5), porBalanza[2]!!.map { it.kg })
        assertEquals(setOf(1L), porBalanza[1]!!.map { it.testId }.toSet())
        assertEquals(setOf(2L), porBalanza[2]!!.map { it.testId }.toSet())
        // La numeración es propia de cada elemento.
        assertEquals(listOf(1, 2), porBalanza[1]!!.map { it.seq })
        assertEquals(listOf(1), porBalanza[2]!!.map { it.seq })
    }

    @Test
    fun corte_de_una_balanza_no_detiene_la_otra() {
        repeat(3) { tick("S" to 0.0, "S" to 0.0) }
        tick("S" to 50.0, "S" to 70.0)
        b2.onLinkLost(clock)                    // se cae la balanza 2 con carga puesta
        repeat(20) { tick("S" to 50.0, null) }  // la balanza 1 sigue leyendo sola
        tick("S" to 0.0, null)
        tick("S" to 60.0, null); tick("S" to 0.0, null)
        assertEquals(listOf(50.0, 60.0), store.rows.filter { it.scaleId == 1 }.map { it.kg })
        assertEquals(0, store.rows.count { it.scaleId == 2 })

        // Vuelve la balanza 2: su ciclo pendiente se cierra una sola vez.
        tick(null, "S" to 70.0); tick(null, "S" to 0.0); tick(null, "S" to 0.0)
        assertEquals(listOf(70.0), store.rows.filter { it.scaleId == 2 }.map { it.kg })
    }
}
