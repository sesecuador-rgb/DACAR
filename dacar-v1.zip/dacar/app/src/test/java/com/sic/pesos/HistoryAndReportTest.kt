package com.sic.pesos

import com.sic.pesos.data.CaptureRecord
import com.sic.pesos.data.HistoryFilter
import com.sic.pesos.data.Units
import com.sic.pesos.data.Weighing
import com.sic.pesos.report.ReportContext
import com.sic.pesos.report.ReportData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate
import java.time.ZoneId

class HistoryAndReportTest {
    private val zone: ZoneId = ZoneId.of("America/Guayaquil")
    private fun ms(y: Int, m: Int, d: Int, h: Int) =
        LocalDate.of(y, m, d).atTime(h, 0).atZone(zone).toInstant().toEpochMilli()

    private fun w(id: Long, scale: Int, test: Long, kg: Double, at: Long, tare: Double = 0.0, sample: Double? = null) =
        Weighing(id, test, id.toInt(), kg, at, "c$id", scaleId = scale, tareKg = tare, sampleKg = sample)

    @Test
    fun total_de_unidades_como_en_el_registro_en_papel() {
        assertEquals(1441L, Units.of(136.0, 10, 0.944))
        assertEquals(2714L, Units.of(905.0, 10, 3.335))
        assertEquals(11039L, Units.of(922.0, 40, 3.341))
        assertNull(Units.of(136.0, 10, null))
    }

    @Test
    fun filtro_combinado_por_balanza_fecha_y_elemento() {
        val f = HistoryFilter(scaleId = 1, fromDay = LocalDate.of(2026, 9, 24), toDay = LocalDate.of(2026, 9, 24), elementId = 5)
        assertTrue(f.matches(w(1, 1, 5, 100.0, ms(2026, 9, 24, 23)), zone))      // último momento del día incluido
        assertFalse(f.matches(w(2, 2, 5, 100.0, ms(2026, 9, 24, 10)), zone))     // otra balanza
        assertFalse(f.matches(w(3, 1, 6, 100.0, ms(2026, 9, 24, 10)), zone))     // otro elemento
        assertFalse(f.matches(w(4, 1, 5, 100.0, ms(2026, 9, 25, 0)), zone))      // día siguiente
        assertFalse(f.matches(w(5, 1, 5, 100.0, ms(2026, 9, 23, 23)), zone))     // día anterior

        val (where, args) = f.toSql(zone)
        assertEquals("WHERE w.scale_id = ? AND w.at_ms >= ? AND w.at_ms < ? AND w.test_id = ?", where)
        assertEquals(4, args.size)
        assertTrue(HistoryFilter().toSql(zone).first.isEmpty())
    }

    @Test
    fun totales_separados_por_balanza_y_sin_mezclar_unidades() {
        val recs = listOf(
            CaptureRecord(w(1, 1, 1, 184.0, 0, tare = 48.0, sample = 0.944), "F30", "21-09-26", 10),
            CaptureRecord(w(2, 1, 1, 1061.0, 0, tare = 55.0, sample = 0.972), "F30", "21-09-26", 10),
            CaptureRecord(w(3, 2, 2, 965.0, 0, tare = 60.0, sample = 3.335), "G70A", "21-09-26", 10),
        )
        val dec = { _: Int -> 1 }
        assertTrue(ReportData.includesSeveralScales(recs))
        val per = ReportData.perScale(recs, dec)
        assertEquals(BigDecimal("1142.0"), per[1]!!.netByUnit["kg"])
        assertEquals(BigDecimal("905.0"), per[2]!!.netByUnit["kg"])
        // Un solo elemento con muestra en todas las filas: el total de unidades sí tiene sentido.
        assertEquals(1441L + 10350L, per[1]!!.totalUnits)
        // Mezclando modelos distintos, sumar piezas no tiene sentido: no se informa.
        assertNull(ReportData.summarize(recs, dec).totalUnits)

        val withLb = recs + CaptureRecord(w(4, 2, 2, 10.0, 0).copy(unit = "lb"), "G70A", "", 10)
        val s = ReportData.summarize(withLb, dec)
        assertEquals(setOf("kg", "lb"), s.netByUnit.keys)      // cada unidad con su propio total
    }

    @Test
    fun lineas_de_filtros_del_reporte() {
        val ctx = ReportContext(
            HistoryFilter(scaleId = null, fromDay = LocalDate.of(2026, 9, 24)),
            mapOf(1 to "Balanza 1", 2 to "Balanza 2"), mapOf(1 to 1, 2 to 1), null, 0L,
        )
        val lines = ReportData.filterLines(ctx).toMap()
        assertEquals("Ambas", lines["Balanza"])
        assertEquals("24/09/2026", lines["Desde"])
        assertEquals("Sin límite", lines["Hasta"])
        assertEquals("Todos", lines["Elemento"])
    }
}
