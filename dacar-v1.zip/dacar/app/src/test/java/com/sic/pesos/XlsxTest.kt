package com.sic.pesos

import com.sic.pesos.data.CaptureRecord
import com.sic.pesos.data.HistoryFilter
import com.sic.pesos.data.Weighing
import com.sic.pesos.report.ReportContext
import com.sic.pesos.report.XlsxReport
import com.sic.pesos.report.XlsxWriter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.LocalDate
import java.time.ZoneId
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class XlsxTest {
    private val zone: ZoneId = ZoneId.of("America/Guayaquil")

    private fun sample(): ByteArray {
        val at = LocalDate.of(2026, 9, 24).atTime(8, 30, 15).atZone(zone).toInstant().toEpochMilli()
        val recs = listOf(
            CaptureRecord(Weighing(1, 1, 1, 184.0, at, "id-1", 1, "kg", 48.0, "Canasta 48 kg", 0.944), "F30", "21-09-26", 10),
            CaptureRecord(Weighing(2, 2, 1, 965.0, at + 60_000, "id-2", 2, "kg", 60.0, null, null), "Prueba <2> & \"otra\"", "", 10),
        )
        val ctx = ReportContext(HistoryFilter(), mapOf(1 to "Balanza 1", 2 to "Balanza 2"), mapOf(1 to 1, 2 to 1), null, at)
        return ByteArrayOutputStream().also { XlsxReport.write(it, recs, ctx, zone) }.toByteArray()
    }

    private fun entries(bytes: ByteArray): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                out[e.name] = z.readBytes().toString(Charsets.UTF_8)
            }
        }
        return out
    }

    @Test
    fun el_archivo_tiene_todas_las_partes_y_xml_valido() {
        val bytes = sample()
        File("build/xlsx-prueba").mkdirs()
        File("build/xlsx-prueba/reporte-prueba.xlsx").writeBytes(bytes) // para abrirlo a mano si hace falta
        val parts = entries(bytes)
        assertEquals(
            setOf("[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/styles.xml", "xl/worksheets/sheet1.xml"),
            parts.keys,
        )
        val dbf = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        parts.values.forEach { xml -> dbf.newDocumentBuilder().parse(ByteArrayInputStream(xml.toByteArray())) }
        val sheet = parts.getValue("xl/worksheets/sheet1.xml")
        assertTrue(sheet.contains("Prueba &lt;2&gt; &amp; &quot;otra&quot;"))
        assertTrue(sheet.contains("<v>184.0</v>"))
        assertTrue(sheet.contains("Balanza 2"))
    }

    @Test
    fun fechas_en_formato_de_excel() {
        val ms = LocalDate.of(2026, 9, 24).atTime(12, 0).atZone(zone).toInstant().toEpochMilli()
        // 24/09/2026 = 46289 en Excel; las 12:00 son medio día (0.5).
        assertEquals(46289.5, XlsxWriter.excelSerial(ms, zone), 1e-6)
        assertEquals("A", XlsxWriter.columnName(0))
        assertEquals("P", XlsxWriter.columnName(15))
        assertEquals("AA", XlsxWriter.columnName(26))
    }
}
