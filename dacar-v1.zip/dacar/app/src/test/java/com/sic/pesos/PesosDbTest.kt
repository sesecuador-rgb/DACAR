package com.sic.pesos

import android.database.sqlite.SQLiteDatabase
import com.sic.pesos.data.CaptureInfo
import com.sic.pesos.data.DbBackup
import com.sic.pesos.data.HistoryFilter
import com.sic.pesos.data.PesosDb
import com.sic.pesos.data.WeightMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File
import java.time.LocalDate
import java.time.ZoneId

/** Base de datos real (SQLite) ejecutada en la PC de compilación con Robolectric. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PesosDbTest {
    private val ctx get() = RuntimeEnvironment.getApplication()

    private fun ms(day: LocalDate, hour: Int) =
        day.atTime(hour, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    @Test
    fun migracion_desde_la_version_anterior_conserva_todo() {
        val f = ctx.getDatabasePath(PesosDb.NAME)
        f.parentFile?.mkdirs()
        ctx.deleteDatabase(PesosDb.NAME)
        // Base exactamente como la dejaba la app v0.2 (esquema versión 1).
        SQLiteDatabase.openOrCreateDatabase(f, null).use { db ->
            PesosDb.createV1(db)
            db.execSQL("INSERT INTO tests(id, number, started_at, finished_at, mode) VALUES (1, 1, 1000, 2000, 'GROSS')")
            db.execSQL("INSERT INTO tests(id, number, started_at, finished_at, mode) VALUES (2, 2, 3000, NULL, 'NET')")
            db.execSQL("INSERT INTO weighings(test_id, seq, weight_kg, at_ms, cycle_id) VALUES (1, 1, 5.0, 1100, 'a')")
            db.execSQL("INSERT INTO weighings(test_id, seq, weight_kg, at_ms, cycle_id) VALUES (1, 2, 7.0, 1200, 'b')")
            db.execSQL("INSERT INTO weighings(test_id, seq, weight_kg, at_ms, cycle_id) VALUES (2, 1, 20.0, 3100, 'c')")
            db.version = 1
        }

        DbBackup.beforeOpen(ctx)
        assertTrue(File(ctx.filesDir, "respaldos/pesos-v1.db").exists())

        val db = PesosDb(ctx)
        assertEquals(listOf("Prueba 2", "Prueba 1"), db.elements(1).map { it.name })
        assertEquals(listOf(5.0, 7.0, 20.0), db.query(HistoryFilter()).map { it.w.kg })
        assertEquals(WeightMode.NET, db.weighings(2).single().mode)
        assertEquals(2L, db.legacyOpenTest()?.id)            // la prueba abierta sigue disponible
        assertTrue(db.baskets().isNotEmpty())
        assertTrue(db.elements(2).isEmpty())                  // nada aparece en la balanza 2
        db.close()
    }

    @Test
    fun dos_balanzas_persisten_al_reabrir_y_se_filtran_combinando() {
        ctx.deleteDatabase(PesosDb.NAME)
        val d1 = LocalDate.of(2026, 9, 24)
        val d2 = d1.plusDays(1)

        var db = PesosDb(ctx)
        val p1 = db.createElement(1, "Prueba 1", "21-09-26", 10, WeightMode.GROSS, 0)
        val p2 = db.createElement(2, "Prueba 2", "", 10, WeightMode.GROSS, 0)
        db.saveWeighing(p1.id, "x1", 184.0, ms(d1, 10), CaptureInfo(scaleId = 1, tareKg = 48.0, basket = "Canasta 48 kg"))
        db.saveWeighing(p2.id, "x2", 96.5, ms(d1, 11), CaptureInfo(scaleId = 2))
        db.saveWeighing(p1.id, "x3", 99.0, ms(d2, 9), CaptureInfo(scaleId = 1))
        assertNull(db.saveWeighing(p1.id, "x1", 184.0, ms(d1, 10), CaptureInfo(scaleId = 1)))  // duplicado
        db.close()

        db = PesosDb(ctx)                                     // cierre y reapertura de la app
        assertEquals(3, db.query(HistoryFilter()).size)
        val r = db.query(HistoryFilter(scaleId = 1, fromDay = d1, toDay = d1, elementId = p1.id))
        assertEquals(listOf(184.0), r.map { it.w.kg })
        assertEquals(136.0, r.single().w.netKg, 1e-9)
        assertEquals("Prueba 1", r.single().elementName)
        assertEquals(listOf(96.5), db.query(HistoryFilter(scaleId = 2)).map { it.w.kg })
        assertEquals(listOf(99.0), db.query(HistoryFilter(fromDay = d2)).map { it.w.kg })
        assertEquals(listOf("Prueba 1"), db.elements(1).map { it.name })
        assertEquals(listOf("Prueba 2"), db.elements(2).map { it.name })

        db.updateCapture(r.single().w.id, "Canasta 55 kg", 55.0, 0.944)
        val edited = db.query(HistoryFilter(elementId = p1.id)).first()
        assertEquals(129.0, edited.w.netKg, 1e-9)
        assertEquals(1367L, edited.units)                     // 129 × 10 / 0,944
        db.close()
    }
}
